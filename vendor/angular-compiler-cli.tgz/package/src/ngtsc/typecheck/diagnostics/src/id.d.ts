/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */
import { DeclarationNode } from '../../../reflection';
import { TypeCheckId } from '@angular/compiler';
export declare function getTypeCheckId(clazz: DeclarationNode): TypeCheckId;
