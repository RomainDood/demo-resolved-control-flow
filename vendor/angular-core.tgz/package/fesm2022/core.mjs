/**
 * @license Angular v22.2.0-next.1+sha-87e0a24-with-local-changes
 * (c) 2010-2026 Google LLC. https://angular.dev/
 * License: MIT
 */

import { RuntimeError, InjectionToken, getCurrentTNode, assertInInjectionContext, inject, promiseWithResolvers, Injector, signalAsReadonlyFn, ɵɵinject as __inject, ɵɵdefineInjector as __defineInjector, ENVIRONMENT_INITIALIZER, APP_ID, unwrapRNode, CLEANUP, makeEnvironmentProviders, formatRuntimeError, TransferState, DOCUMENT, ChangeDetectionScheduler, NgZone, DOC_PAGE_BASE_URL, DEBUG_TASK_TRACKER, stringify, ɵɵdefineInjectable as __defineInjectable, isComponentHost, getComponentLViewByIndex, DECLARATION_COMPONENT_VIEW, registerSpecialProvider, getLView, provideEnvironmentInitializer, ErrorHandler, ZONELESS_ENABLED, SCHEDULE_IN_ROOT_ZONE_DEFAULT, SCHEDULE_IN_ROOT_ZONE, INTERNAL_APPLICATION_ERROR_HANDLER, PendingTasksInternal, assertNgModuleType, IMAGE_CONFIG, ERROR_DETAILS_PAGE_BASE_URL, PROVIDED_ZONELESS, errorHandlerEnvironmentInitializer, validAppIdInitializer, TVIEW, getLViewParent, R3Injector, NullInjector, INJECTOR, T_HOST, PLATFORM_INITIALIZER, runInInjectionContext, INJECTOR_SCOPE, isLContainer, hasI18n, RENDERER, unwrapLView, HOST, getComponentDef, assertTNode, isProjectionTNode, PARENT, CONTEXT, HEADER_OFFSET, isRootView, CONTAINER_HEADER_OFFSET, assertNotInReactiveContext, ViewContext, DestroyRef, setInjectorProfilerContext, emitAfterRenderEffectPhaseCreatedEvent, getNullInjector, isSignal, effect, _global } from './_pending_tasks-chunk.mjs';
export { ANIMATION_MODULE_TYPE, CSP_NONCE, EnvironmentInjector, EventEmitter, INJECTOR$1 as INJECTOR, PLATFORM_ID, PendingTasks, SecurityContext, VERSION, Version, forwardRef, importProvidersFrom, isStandalone, isWritableSignal, makeStateKey, provideBrowserGlobalErrorListeners, resolveForwardRef, signal, EffectScheduler as ɵEffectScheduler, IMAGE_CONFIG_DEFAULTS as ɵIMAGE_CONFIG_DEFAULTS, NG_COMP_DEF as ɵNG_COMP_DEF, NG_DIR_DEF as ɵNG_DIR_DEF, NG_ELEMENT_ID as ɵNG_ELEMENT_ID, NG_INJ_DEF as ɵNG_INJ_DEF, NG_MOD_DEF as ɵNG_MOD_DEF, NG_PIPE_DEF as ɵNG_PIPE_DEF, NG_PROV_DEF as ɵNG_PROV_DEF, NoopNgZone as ɵNoopNgZone, XSS_SECURITY_URL as ɵXSS_SECURITY_URL, convertToBitFlags as ɵconvertToBitFlags, createInjector as ɵcreateInjector, getInjectableDef as ɵgetInjectableDef, isEnvironmentProviders as ɵisEnvironmentProviders, isInjectable as ɵisInjectable, store as ɵstore, truncateMiddle as ɵtruncateMiddle, ɵunwrapWritableSignal, ɵɵdisableBindings, ɵɵenableBindings, ɵɵinvalidFactoryDep, ɵɵnamespaceHTML, ɵɵnamespaceMathML, ɵɵnamespaceSVG, ɵɵresetView, ɵɵrestoreView } from './_pending_tasks-chunk.mjs';
import { ɵɵinjectAttribute as __injectAttribute, IDLE_SERVICE, createMultiResultQuerySignalFn, createSingleResultRequiredQuerySignalFn, createSingleResultOptionalQuerySignalFn, makePropDecorator, ɵɵdefineNgModule as __defineNgModule, ApplicationRef, setClassMetadata, NgModule, IS_EVENT_REPLAY_ENABLED, setStashFn, APP_BOOTSTRAP_LISTENER, JSACTION_EVENT_CONTRACT, JSACTION_BLOCK_ELEMENT_MAP, removeListeners, isIncrementalHydrationEnabled, performanceMarkFeature, EVENT_REPLAY_ENABLED_DEFAULT, sharedStashFunction, sharedMapFunction, DEFER_BLOCK_SSR_ID_ATTRIBUTE, invokeListeners, EVENT_REPLAY_QUEUE, triggerHydrationFromBlockName, enableStashEventListenerImpl, IS_HYDRATION_DOM_REUSE_ENABLED, IS_I18N_HYDRATION_ENABLED, IS_INCREMENTAL_HYDRATION_ENABLED, createDehydratedBlockRegistry, DEHYDRATED_BLOCK_REGISTRY, INCREMENTAL_HYDRATION_BOOTSTRAP, runIncrementalHydrationBootstrap, NGH_DATA_KEY, verifySsrContentsIntegrity, enableRetrieveHydrationInfoImpl, enableLocateOrCreateElementNodeImpl, enableLocateOrCreateTextNodeImpl, enableLocateOrCreateContainerRefImpl, enableFindMatchingDehydratedViewImpl, enableLocateOrCreateElementContainerNodeImpl, enableLocateOrCreateContainerAnchorImpl, enableApplyRootElementTransformImpl, setIsI18nHydrationSupportEnabled, Console, PRESERVE_HOST_CONTENT, cleanupDehydratedViews, countBlocksSkippedByHydration, enableLocateOrCreateI18nNodeImpl, enablePrepareI18nBlockForHydrationImpl, enableClaimDehydratedIcuCaseImpl, provideAppInitializer, isListLikeIterable, iterateListLike, isJsObject, ViewRef as ViewRef$1, checkNoChangesInternal, ChangeDetectionSchedulerImpl, UseExhaustiveCheckNoChanges, ɵɵdefineService as __defineService, Service, NgModuleFactory, COMPILER_OPTIONS, setJitOptions, isComponentResourceResolutionQueueEmpty, getCompilerFacade, resolveComponentResources, getDocument, remove, isPromise, ApplicationInitStatus, LOCALE_ID, DEFAULT_LOCALE_ID, setLocaleId, createNgModuleRefWithProviders, optionsReducer, Injectable, provideZonelessChangeDetectionInternal, getInjectorMetadata, getInjectorProviders, getNodeInjectorTNode, getLContext, walkLViewDirectives, NodeInjector, ChainedInjector, getInjector, getSignalGraph, publishDefaultGlobalUtils, publishSignalConfiguration, profiler, assertStandaloneComponentType, EnvironmentNgModuleRefAdapter, ProfilerEvent, isI18nHydrationEnabled, NGH_DEFER_BLOCKS_KEY, getLNodeForHydration, NGH_ATTR_NAME, SKIP_HYDRATION_ATTR_NAME, isI18nHydrationSupportEnabled, ViewEncapsulation as ViewEncapsulation$1, getOrComputeI18nChildren, trySerializeI18nBlock, I18N_DATA, isTNodeShape, isDetachedByI18n, TEMPLATES, isDisconnectedNode, isInSkipHydrationBlock, unsupportedProjectionOfDomNodes, CONTAINERS, isLetDeclaration, ELEMENT_CONTAINERS, processTextNodeBeforeSerialization, setJSActionAttributes, DISCONNECTED_NODES, NODES, calcPathForNode, NUM_ROOT_NODES, TEMPLATE_ID, isDeferBlock, getLDeferBlockDetails, getTDeferBlockDetails, collectNativeNodesInLContainer, validateNodeExists, validateMatchingNode, DEFER_BLOCK_ID, DEFER_BLOCK_STATE, DEFER_BLOCK_STATE$1, MULTIPLIER, collectNativeNodes, convertHydrateTriggersToJsAction, DEFER_HYDRATE_TRIGGERS, DEFER_PARENT_BLOCK_ID, NOOP_AFTER_RENDER_REF, AfterRenderManager, TracingService, AfterRenderImpl, AfterRenderSequence, AFTER_RENDER_PHASES, setClassMetadataAsync, angularCoreEnv, getRegisteredNgModuleType, assertComponentDef, ComponentFactory } from './_debug_node-chunk.mjs';
export { APP_INITIALIZER, Attribute, CUSTOM_ELEMENTS_SCHEMA, ChangeDetectionStrategy, Compiler, CompilerFactory, Component, ComponentRef, DEFAULT_CURRENCY_CODE, DebugElement, DebugEventListener, DebugNode, Directive, ElementRef, Host, HostBinding, HostListener, Inject, Input, MAX_ANIMATION_TIMEOUT, MissingTranslationStrategy, NO_ERRORS_SCHEMA, NgModuleFactory$1 as NgModuleFactory, NgModuleRef$1 as NgModuleRef, Optional, Output, Pipe, QueryList, Renderer2, RendererFactory2, RendererStyleFlags2, Sanitizer, Self, SimpleChange, SkipSelf, TRANSLATIONS, TRANSLATIONS_FORMAT, TemplateRef, Testability, TestabilityRegistry, Type, ViewContainerRef, afterEveryRender, afterNextRender, asNativeElements, createEnvironmentInjector, createNgModule, enableProfiling, getDebugNode, inputBinding, outputBinding, provideIdleServiceWith, provideNgReflectAttributes, provideZonelessChangeDetection, setTestabilityGetter, twoWayBinding, ANIMATIONS_DISABLED as ɵANIMATIONS_DISABLED, AcxChangeDetectionStrategy as ɵAcxChangeDetectionStrategy, AcxViewEncapsulation as ɵAcxViewEncapsulation, ControlFlowBlockType as ɵControlFlowBlockType, DEFER_BLOCK_CONFIG as ɵDEFER_BLOCK_CONFIG, DEFER_BLOCK_DEPENDENCY_INTERCEPTOR as ɵDEFER_BLOCK_DEPENDENCY_INTERCEPTOR, DeferBlockBehavior as ɵDeferBlockBehavior, DeferBlockState as ɵDeferBlockState, HydrationStatus as ɵHydrationStatus, IS_ENABLED_BLOCKING_INITIAL_NAVIGATION as ɵIS_ENABLED_BLOCKING_INITIAL_NAVIGATION, LContext as ɵLContext, LocaleDataIndex as ɵLocaleDataIndex, NOT_FOUND_CHECK_ONLY_ELEMENT_INJECTOR as ɵNOT_FOUND_CHECK_ONLY_ELEMENT_INJECTOR, NO_CHANGE as ɵNO_CHANGE, ReflectionCapabilities as ɵReflectionCapabilities, ComponentRef$1 as ɵRender3ComponentRef, NgModuleRef as ɵRender3NgModuleRef, SHARED_STYLES_HOST as ɵSHARED_STYLES_HOST, SSR_CONTENT_INTEGRITY_MARKER as ɵSSR_CONTENT_INTEGRITY_MARKER, TESTABILITY as ɵTESTABILITY, TESTABILITY_GETTER as ɵTESTABILITY_GETTER, TimerScheduler as ɵTimerScheduler, TracingAction as ɵTracingAction, USE_PENDING_TASKS as ɵUSE_PENDING_TASKS, _sanitizeHtml as ɵ_sanitizeHtml, _sanitizeUrl as ɵ_sanitizeUrl, allLeavingAnimations as ɵallLeavingAnimations, allowSanitizationBypassAndThrow as ɵallowSanitizationBypassAndThrow, bypassSanitizationTrustHtml as ɵbypassSanitizationTrustHtml, bypassSanitizationTrustResourceUrl as ɵbypassSanitizationTrustResourceUrl, bypassSanitizationTrustScript as ɵbypassSanitizationTrustScript, bypassSanitizationTrustStyle as ɵbypassSanitizationTrustStyle, bypassSanitizationTrustUrl as ɵbypassSanitizationTrustUrl, clearResolutionOfComponentResourcesQueue as ɵclearResolutionOfComponentResourcesQueue, compileComponent as ɵcompileComponent, compileDirective as ɵcompileDirective, compileNgModule as ɵcompileNgModule, compileNgModuleDefs as ɵcompileNgModuleDefs, compilePipe as ɵcompilePipe, depsTracker as ɵdepsTracker, devModeEqual as ɵdevModeEqual, findLocaleData as ɵfindLocaleData, flushModuleScopingQueueAsMuchAsPossible as ɵflushModuleScopingQueueAsMuchAsPossible, generateStandaloneInDeclarationsError as ɵgenerateStandaloneInDeclarationsError, getAsyncClassMetadataFn as ɵgetAsyncClassMetadataFn, getClosestComponentName as ɵgetClosestComponentName, getComponentInstanceDeepLinkId as ɵgetComponentInstanceDeepLinkId, getDeferBlocks as ɵgetDeferBlocks, getDirectives as ɵgetDirectives, getHostElement as ɵgetHostElement, getLocaleCurrencyCode as ɵgetLocaleCurrencyCode, getLocalePluralCase as ɵgetLocalePluralCase, getSanitizationBypassType as ɵgetSanitizationBypassType, getTransferState as ɵgetTransferState, ɵgetUnknownElementStrictMode, ɵgetUnknownPropertyStrictMode, inferTagNameFromDefinition as ɵinferTagNameFromDefinition, isComponentDefPendingResolution as ɵisComponentDefPendingResolution, isNgModule as ɵisNgModule, isSubscribable as ɵisSubscribable, isViewDirty as ɵisViewDirty, markForRefresh as ɵmarkForRefresh, noSideEffects as ɵnoSideEffects, patchComponentDefWithScope as ɵpatchComponentDefWithScope, publishNonCoreGlobalUtil as ɵpublishNonCoreGlobalUtil, readHydrationInfo as ɵreadHydrationInfo, registerLocaleData as ɵregisterLocaleData, renderDeferBlockState as ɵrenderDeferBlockState, resetCompiledComponents as ɵresetCompiledComponents, resetIncrementalHydrationEnabledWarnedForTests as ɵresetIncrementalHydrationEnabledWarnedForTests, resetIncrementalHydrationRuntimeForTests as ɵresetIncrementalHydrationRuntimeForTests, resetJitOptions as ɵresetJitOptions, restoreComponentResolutionQueue as ɵrestoreComponentResolutionQueue, setAllowDuplicateNgModuleIdsForTest as ɵsetAllowDuplicateNgModuleIdsForTest, ɵsetClassDebugInfo, setDocument as ɵsetDocument, ɵsetUnknownElementStrictMode, ɵsetUnknownPropertyStrictMode, transitiveScopesFor as ɵtransitiveScopesFor, triggerResourceLoading as ɵtriggerResourceLoading, unregisterAllLocaleData as ɵunregisterLocaleData, unwrapSafeValue as ɵunwrapSafeValue, ɵɵControlFeature, ɵɵExternalStylesFeature, ɵɵHostDirectivesFeature, ɵɵInheritDefinitionFeature, ɵɵNgOnChangesFeature, ɵɵProvidersFeature, ɵɵadvance, ɵɵanimateEnter, ɵɵanimateEnterListener, ɵɵanimateLeave, ɵɵanimateLeaveListener, ɵɵariaProperty, ɵɵarrowFunction, ɵɵattachSourceLocations, ɵɵattribute, ɵɵclassMap, ɵɵclassProp, ɵɵcomponentInstance, ɵɵconditional, ɵɵconditionalBranchCreate, ɵɵconditionalCreate, ɵɵcontentQuery, ɵɵcontentQuerySignal, ɵɵcontrol, ɵɵcontrolCreate, ɵɵdeclareLet, ɵɵdefer, ɵɵdeferEnableTimerScheduling, ɵɵdeferHydrateNever, ɵɵdeferHydrateOnHover, ɵɵdeferHydrateOnIdle, ɵɵdeferHydrateOnImmediate, ɵɵdeferHydrateOnInteraction, ɵɵdeferHydrateOnTimer, ɵɵdeferHydrateOnViewport, ɵɵdeferHydrateWhen, ɵɵdeferOnHover, ɵɵdeferOnIdle, ɵɵdeferOnImmediate, ɵɵdeferOnInteraction, ɵɵdeferOnTimer, ɵɵdeferOnViewport, ɵɵdeferPrefetchOnHover, ɵɵdeferPrefetchOnIdle, ɵɵdeferPrefetchOnImmediate, ɵɵdeferPrefetchOnInteraction, ɵɵdeferPrefetchOnTimer, ɵɵdeferPrefetchOnViewport, ɵɵdeferPrefetchWhen, ɵɵdeferWhen, ɵɵdefineComponent, ɵɵdefineDirective, ɵɵdefinePipe, ɵɵdirectiveInject, ɵɵdomElement, ɵɵdomElementContainer, ɵɵdomElementContainerEnd, ɵɵdomElementContainerStart, ɵɵdomElementEnd, ɵɵdomElementStart, ɵɵdomListener, ɵɵdomProperty, ɵɵdomTemplate, ɵɵelement, ɵɵelementContainer, ɵɵelementContainerEnd, ɵɵelementContainerStart, ɵɵelementEnd, ɵɵelementStart, ɵɵenableIncrementalHydrationRuntime, ɵɵforeignComponent, ɵɵforeignContent, ɵɵforeignContentFn, ɵɵgetComponentDepsFactory, ɵɵgetCurrentView, ɵɵgetInheritedFactory, ɵɵgetReplaceMetadataURL, ɵɵi18n, ɵɵi18nApply, ɵɵi18nAttributes, ɵɵi18nEnd, ɵɵi18nExp, ɵɵi18nPostprocess, ɵɵi18nStart, ɵɵinterpolate, ɵɵinterpolate1, ɵɵinterpolate2, ɵɵinterpolate3, ɵɵinterpolate4, ɵɵinterpolate5, ɵɵinterpolate6, ɵɵinterpolate7, ɵɵinterpolate8, ɵɵinterpolateV, ɵɵinvalidFactory, ɵɵlistener, ɵɵloadQuery, ɵɵnextContext, ɵɵpending, ɵɵpipe, ɵɵpipeBind1, ɵɵpipeBind2, ɵɵpipeBind3, ɵɵpipeBind4, ɵɵpipeBindV, ɵɵprojection, ɵɵprojectionDef, ɵɵproperty, ɵɵpureFunction0, ɵɵpureFunction1, ɵɵpureFunction2, ɵɵpureFunction3, ɵɵpureFunction4, ɵɵpureFunction5, ɵɵpureFunction6, ɵɵpureFunction7, ɵɵpureFunction8, ɵɵpureFunctionV, ɵɵqueryAdvance, ɵɵqueryRefresh, ɵɵreadContextLet, ɵɵreference, registerNgModuleType as ɵɵregisterNgModuleType, ɵɵrepeater, ɵɵrepeaterCreate, ɵɵrepeaterTrackByIdentity, ɵɵrepeaterTrackByIndex, ɵɵreplaceMetadata, ɵɵresolveBody, ɵɵresolveDocument, ɵɵresolveWindow, ɵɵsanitizeHtml, ɵɵsanitizeResourceUrl, ɵɵsanitizeScript, ɵɵsanitizeStyle, ɵɵsanitizeUrl, ɵɵsanitizeUrlOrResourceUrl, ɵɵsetComponentScope, ɵɵsetNgModuleScope, ɵɵstoreLet, ɵɵstyleMap, ɵɵstyleProp, ɵɵsyntheticHostListener, ɵɵsyntheticHostProperty, ɵɵtemplate, ɵɵtemplateRefExtractor, ɵɵtext, ɵɵtextInterpolate, ɵɵtextInterpolate1, ɵɵtextInterpolate2, ɵɵtextInterpolate3, ɵɵtextInterpolate4, ɵɵtextInterpolate5, ɵɵtextInterpolate6, ɵɵtextInterpolate7, ɵɵtextInterpolate8, ɵɵtextInterpolateV, ɵɵtrustConstantHtml, ɵɵtrustConstantResourceUrl, ɵɵtwoWayBindingSet, ɵɵtwoWayListener, ɵɵtwoWayProperty, ɵɵvalidateAttribute, ɵɵviewQuery, ɵɵviewQuerySignal } from './_debug_node-chunk.mjs';
import { SIGNAL_NODE, signalSetFn, SIGNAL, producerAccessed, consumerDestroy, consumerPollProducersForChange, consumerBeforeComputation, consumerAfterComputation, NotReady, getActiveConsumer } from './_effect-chunk.mjs';
export { isNotReady } from './_effect-chunk.mjs';
import { OutputEmitterRef, computed, ResourceValueError, linkedSignal, isInParamsFunction, invalidResourceCreationInParams, setInParamsFunction, rethrowFatalErrors, untracked, assertAsyncReadAllowed, ResourceParamsStatus } from './_resource-chunk.mjs';
export { ResourceDependencyError, resource, CACHE_ACTIVE as ɵCACHE_ACTIVE, ResourceImpl as ɵResourceImpl, chain as ɵchain, encapsulateResourceError as ɵencapsulateResourceError, getOutputDestroyRef as ɵgetOutputDestroyRef } from './_resource-chunk.mjs';
import { Subscription } from 'rxjs';
import { clearAppScopedEarlyEventContract, EventContract, EventContractContainer, EventDispatcher, registerDispatcher, getAppScopedQueuedEventInfos, EventPhase, isEarlyEventType, isCaptureEventType } from './primitives-event-dispatch.mjs';
export { setAlternateWeakRefImpl as ɵsetAlternateWeakRefImpl } from './_weak_ref-chunk.mjs';
export { setCurrentInjector as ɵsetCurrentInjector } from './_not_found-chunk.mjs';
import '@angular/core/primitives/signals';
import '@angular/core/primitives/di';
import 'rxjs/operators';
import './_attribute-chunk.mjs';
import './_untracked-chunk.mjs';

const REQUIRED_UNSET_VALUE = /* @__PURE__ */Symbol('InputSignalNode#UNSET');
const INPUT_SIGNAL_NODE = /* @__PURE__ */(() => {
  return {
    ...SIGNAL_NODE,
    transformFn: undefined,
    applyValueToInputSignal(node, value) {
      signalSetFn(node, value);
    }
  };
})();

const ɵINPUT_SIGNAL_BRAND_WRITE_TYPE = /* @__PURE__ */Symbol();
function createInputSignal(initialValue, options) {
  const node = Object.create(INPUT_SIGNAL_NODE);
  node.value = initialValue;
  node.transformFn = options?.transform;
  function inputValueFn() {
    producerAccessed(node);
    if (node.value === REQUIRED_UNSET_VALUE) {
      let message = null;
      if (ngDevMode) {
        const name = options?.debugName ?? options?.alias;
        message = `Input${name ? ` "${name}"` : ''} is required but no value is available yet.`;
      }
      throw new RuntimeError(-950, message);
    }
    return node.value;
  }
  inputValueFn[SIGNAL] = node;
  if (ngDevMode) {
    inputValueFn.toString = () => `[Input Signal: ${inputValueFn()}]`;
    node.debugName = options?.debugName;
  }
  return inputValueFn;
}

var Framework;
(function (Framework) {
  Framework["Angular"] = "angular";
  Framework["ACX"] = "acx";
  Framework["Wiz"] = "wiz";
})(Framework || (Framework = {}));

class HostAttributeToken {
  attributeName;
  constructor(attributeName) {
    this.attributeName = attributeName;
  }
  __NG_ELEMENT_ID__ = () => __injectAttribute(this.attributeName);
  toString() {
    return `HostAttributeToken ${this.attributeName}`;
  }
}

const HOST_TAG_NAME = /* @__PURE__ */(() => {
  
  const HOST_TAG_NAME_TOKEN = new InjectionToken(typeof ngDevMode !== 'undefined' && ngDevMode ? 'HOST_TAG_NAME' : '');
  HOST_TAG_NAME_TOKEN.__NG_ELEMENT_ID__ = flags => {
    const tNode = getCurrentTNode();
    if (tNode === null) {
      throw new RuntimeError(-204, ngDevMode && 'HOST_TAG_NAME can only be injected in directives and components ' + 'during construction time (in a class constructor or as a class field initializer)');
    }
    if (tNode.type & 2) {
      return tNode.value;
    }
    if (flags & 8) {
      return null;
    }
    throw new RuntimeError(-204, ngDevMode && `HOST_TAG_NAME was used on ${getDevModeNodeName(tNode)} which doesn't have an underlying element in the DOM. ` + `This is invalid, and so the dependency should be marked as optional.`);
  };
  return HOST_TAG_NAME_TOKEN;
})();
function getDevModeNodeName(tNode) {
  if (tNode.type & 8) {
    return 'an <ng-container>';
  } else if (tNode.type & 4) {
    return 'an <ng-template>';
  } else if (tNode.type & 128) {
    return 'an @let declaration';
  } else {
    return 'a node';
  }
}

function maybeUnwrapDefaultExport(input) {
  return isWrappedDefaultExport(input) ? input['default'] : input;
}
function isWrappedDefaultExport(value) {
  return value && typeof value === 'object' && 'default' in value;
}

function injectAsync(loader, options) {
  if (ngDevMode) {
    assertInInjectionContext(injectAsync);
  }
  const injector = inject(Injector);
  let loadedPromise = null;
  const load = () => {
    if (!loadedPromise) {
      loadedPromise = loader();
    }
    return loadedPromise;
  };
  if (options?.prefetch) {
    options.prefetch().then(() => load()).catch(() => {});
  }
  return () => load().then(loadedToken => injector.get(maybeUnwrapDefaultExport(loadedToken)));
}
function onIdle(options) {
  if (ngDevMode) {
    assertInInjectionContext(onIdle);
  }
  const idleService = inject(IDLE_SERVICE);
  const {
    promise,
    resolve
  } = promiseWithResolvers();
  idleService.requestOnIdle(() => resolve(), options);
  return promise;
}

var FactoryTarget;
(function (FactoryTarget) {
  FactoryTarget[FactoryTarget["Directive"] = 0] = "Directive";
  FactoryTarget[FactoryTarget["Component"] = 1] = "Component";
  FactoryTarget[FactoryTarget["Injectable"] = 2] = "Injectable";
  FactoryTarget[FactoryTarget["Pipe"] = 3] = "Pipe";
  FactoryTarget[FactoryTarget["NgModule"] = 4] = "NgModule";
  FactoryTarget[FactoryTarget["Service"] = 5] = "Service";
})(FactoryTarget || (FactoryTarget = {}));
var R3TemplateDependencyKind;
(function (R3TemplateDependencyKind) {
  R3TemplateDependencyKind[R3TemplateDependencyKind["Directive"] = 0] = "Directive";
  R3TemplateDependencyKind[R3TemplateDependencyKind["Pipe"] = 1] = "Pipe";
  R3TemplateDependencyKind[R3TemplateDependencyKind["NgModule"] = 2] = "NgModule";
})(R3TemplateDependencyKind || (R3TemplateDependencyKind = {}));
var ViewEncapsulation;
(function (ViewEncapsulation) {
  ViewEncapsulation[ViewEncapsulation["Emulated"] = 0] = "Emulated";
  ViewEncapsulation[ViewEncapsulation["None"] = 2] = "None";
  ViewEncapsulation[ViewEncapsulation["ShadowDom"] = 3] = "ShadowDom";
  ViewEncapsulation[ViewEncapsulation["ExperimentalIsolatedShadowDom"] = 4] = "ExperimentalIsolatedShadowDom";
})(ViewEncapsulation || (ViewEncapsulation = {}));

function output(opts) {
  ngDevMode && assertInInjectionContext(output);
  return new OutputEmitterRef();
}

function inputFunction(initialValue, opts) {
  ngDevMode && assertInInjectionContext(input);
  return createInputSignal(initialValue, opts);
}
function inputRequiredFunction(opts) {
  ngDevMode && assertInInjectionContext(input);
  return createInputSignal(REQUIRED_UNSET_VALUE, opts);
}
const input = (() => {
  inputFunction.required = inputRequiredFunction;
  return inputFunction;
})();

function createModelSignal(initialValue, opts) {
  const node = Object.create(INPUT_SIGNAL_NODE);
  const emitterRef = new OutputEmitterRef();
  node.value = initialValue;
  function getter() {
    producerAccessed(node);
    assertModelSet(node.value);
    return node.value;
  }
  getter[SIGNAL] = node;
  getter.asReadonly = signalAsReadonlyFn.bind(getter);
  getter.set = newValue => {
    if (!node.equal(node.value, newValue)) {
      signalSetFn(node, newValue);
      emitterRef.emit(newValue);
    }
  };
  getter.update = updateFn => {
    assertModelSet(node.value);
    getter.set(updateFn(node.value));
  };
  getter.subscribe = emitterRef.subscribe.bind(emitterRef);
  getter.destroyRef = emitterRef.destroyRef;
  if (ngDevMode) {
    getter.toString = () => `[Model Signal: ${getter()}]`;
    node.debugName = opts?.debugName;
  }
  return getter;
}
function assertModelSet(value) {
  if (value === REQUIRED_UNSET_VALUE) {
    throw new RuntimeError(952, ngDevMode && 'Model is required but no value is available yet.');
  }
}

function modelFunction(initialValue, opts) {
  ngDevMode && assertInInjectionContext(model);
  return createModelSignal(initialValue, opts);
}
function modelRequiredFunction(opts) {
  ngDevMode && assertInInjectionContext(model);
  return createModelSignal(REQUIRED_UNSET_VALUE, opts);
}
const model = (() => {
  modelFunction.required = modelRequiredFunction;
  return modelFunction;
})();

function viewChildFn(locator, opts) {
  ngDevMode && assertInInjectionContext(viewChild);
  return createSingleResultOptionalQuerySignalFn(opts);
}
function viewChildRequiredFn(locator, opts) {
  ngDevMode && assertInInjectionContext(viewChild);
  return createSingleResultRequiredQuerySignalFn(opts);
}
const viewChild = (() => {
  viewChildFn.required = viewChildRequiredFn;
  return viewChildFn;
})();
function viewChildren(locator, opts) {
  ngDevMode && assertInInjectionContext(viewChildren);
  return createMultiResultQuerySignalFn(opts);
}
function contentChildFn(locator, opts) {
  ngDevMode && assertInInjectionContext(contentChild);
  return createSingleResultOptionalQuerySignalFn(opts);
}
function contentChildRequiredFn(locator, opts) {
  ngDevMode && assertInInjectionContext(contentChildren);
  return createSingleResultRequiredQuerySignalFn(opts);
}
const contentChild = (() => {
  contentChildFn.required = contentChildRequiredFn;
  return contentChildFn;
})();
function contentChildren(locator, opts) {
  return createMultiResultQuerySignalFn(opts);
}

function mergeApplicationConfig(...configs) {
  return configs.reduce((prev, curr) => {
    return Object.assign(prev, curr, {
      providers: [...prev.providers, ...curr.providers]
    });
  }, {
    providers: []
  });
}

const emitDistinctChangesOnlyDefaultValue = true;
class Query {}
const ContentChildren = makePropDecorator('ContentChildren', (selector, opts = {}) => ({
  selector,
  first: false,
  isViewQuery: false,
  descendants: false,
  emitDistinctChangesOnly: emitDistinctChangesOnlyDefaultValue,
  ...opts
}), Query);
const ContentChild = makePropDecorator('ContentChild', (selector, opts = {}) => ({
  selector,
  first: true,
  isViewQuery: false,
  descendants: true,
  ...opts
}), Query);
const ViewChildren = makePropDecorator('ViewChildren', (selector, opts = {}) => ({
  selector,
  first: false,
  isViewQuery: true,
  descendants: true,
  emitDistinctChangesOnly: emitDistinctChangesOnlyDefaultValue,
  ...opts
}), Query);
const ViewChild = makePropDecorator('ViewChild', (selector, opts) => ({
  selector,
  first: true,
  isViewQuery: true,
  descendants: true,
  ...opts
}), Query);

class ApplicationModule {
  constructor(appRef) {}
  static ɵfac = function ApplicationModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ApplicationModule)(__inject(ApplicationRef));
  };
  static ɵmod = /*@__PURE__*/__defineNgModule({
    type: ApplicationModule
  });
  static ɵinj = /*@__PURE__*/__defineInjector({});
}
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ApplicationModule, [{
    type: NgModule
  }], () => [{
    type: ApplicationRef
  }], null);
})();

const REQUEST = new InjectionToken(typeof ngDevMode === 'undefined' || ngDevMode ? 'REQUEST' : '', {
  providedIn: 'platform',
  factory: () => null
});
const RESPONSE_INIT = new InjectionToken(typeof ngDevMode === 'undefined' || ngDevMode ? 'RESPONSE_INIT' : '', {
  providedIn: 'platform',
  factory: () => null
});
const REQUEST_CONTEXT = new InjectionToken(typeof ngDevMode === 'undefined' || ngDevMode ? 'REQUEST_CONTEXT' : '', {
  providedIn: 'platform',
  factory: () => null
});

const appsWithEventReplay = new WeakSet();
const EAGER_CONTENT_LISTENERS_KEY = '';
function shouldEnableEventReplay(injector) {
  return injector.get(IS_EVENT_REPLAY_ENABLED, EVENT_REPLAY_ENABLED_DEFAULT);
}
function withEventReplay() {
  const providers = [{
    provide: IS_EVENT_REPLAY_ENABLED,
    useFactory: () => {
      let isEnabled = true;
      if (typeof ngServerMode === 'undefined' || !ngServerMode) {
        const appId = inject(APP_ID);
        isEnabled = !!window._ejsas?.[appId];
      }
      if (isEnabled) {
        performanceMarkFeature('NgEventReplay');
      }
      return isEnabled;
    }
  }];
  if (typeof ngServerMode === 'undefined' || !ngServerMode) {
    providers.push({
      provide: ENVIRONMENT_INITIALIZER,
      useValue: () => {
        const appRef = inject(ApplicationRef);
        const {
          injector
        } = appRef;
        if (!appsWithEventReplay.has(appRef)) {
          const jsActionMap = inject(JSACTION_BLOCK_ELEMENT_MAP);
          if (shouldEnableEventReplay(injector)) {
            enableStashEventListenerImpl();
            const appId = injector.get(APP_ID);
            const clearStashFn = setStashFn(appId, (rEl, eventName, listenerFn) => {
              if (rEl.nodeType !== Node.ELEMENT_NODE) return;
              sharedStashFunction(rEl, eventName, listenerFn);
              sharedMapFunction(rEl, jsActionMap);
            });
            appRef.onDestroy(clearStashFn);
          }
        }
      },
      multi: true
    }, {
      provide: APP_BOOTSTRAP_LISTENER,
      useFactory: () => {
        const appRef = inject(ApplicationRef);
        const {
          injector
        } = appRef;
        return () => {
          if (!shouldEnableEventReplay(injector) || appsWithEventReplay.has(appRef)) {
            return;
          }
          appsWithEventReplay.add(appRef);
          const appId = injector.get(APP_ID);
          appRef.onDestroy(() => {
            appsWithEventReplay.delete(appRef);
            if (typeof ngServerMode !== 'undefined' && !ngServerMode) {
              clearAppScopedEarlyEventContract(appId);
            }
          });
          appRef.whenStable().then(() => {
            if (appRef.destroyed) {
              return;
            }
            const eventContractDetails = injector.get(JSACTION_EVENT_CONTRACT);
            initEventReplay(eventContractDetails, injector);
            const jsActionMap = injector.get(JSACTION_BLOCK_ELEMENT_MAP);
            jsActionMap.get(EAGER_CONTENT_LISTENERS_KEY)?.forEach(removeListeners);
            jsActionMap.delete(EAGER_CONTENT_LISTENERS_KEY);
            const eventContract = eventContractDetails.instance;
            if (isIncrementalHydrationEnabled(injector)) {
              appRef.onDestroy(() => eventContract.cleanUp());
            } else {
              eventContract.cleanUp();
            }
          });
        };
      },
      multi: true
    });
  }
  return providers;
}
const initEventReplay = (eventDelegation, injector) => {
  const appId = injector.get(APP_ID);
  const earlyJsactionData = window._ejsas[appId];
  const eventContract = eventDelegation.instance = new EventContract(new EventContractContainer(earlyJsactionData.c));
  for (const et of earlyJsactionData.et) {
    eventContract.addEvent(et);
  }
  for (const et of earlyJsactionData.etc) {
    eventContract.addEvent(et);
  }
  const eventInfos = getAppScopedQueuedEventInfos(appId);
  eventContract.replayEarlyEventInfos(eventInfos);
  clearAppScopedEarlyEventContract(appId);
  const dispatcher = new EventDispatcher(event => {
    invokeRegisteredReplayListeners(injector, event, event.currentTarget);
  });
  registerDispatcher(eventContract, dispatcher);
};
function collectDomEventsInfo(tView, lView, eventTypesToReplay) {
  const domEventsInfo = new Map();
  const lCleanup = lView[CLEANUP];
  const tCleanup = tView.cleanup;
  if (!tCleanup || !lCleanup) {
    return domEventsInfo;
  }
  for (let i = 0; i < tCleanup.length;) {
    const firstParam = tCleanup[i++];
    const secondParam = tCleanup[i++];
    if (typeof firstParam !== 'string') {
      continue;
    }
    const eventType = firstParam;
    if (!isEarlyEventType(eventType)) {
      continue;
    }
    if (isCaptureEventType(eventType)) {
      eventTypesToReplay.capture.add(eventType);
    } else {
      eventTypesToReplay.regular.add(eventType);
    }
    const listenerElement = unwrapRNode(lView[secondParam]);
    i++;
    const useCaptureOrIndx = tCleanup[i++];
    const isDomEvent = typeof useCaptureOrIndx === 'boolean' || useCaptureOrIndx >= 0;
    if (!isDomEvent) {
      continue;
    }
    if (!domEventsInfo.has(listenerElement)) {
      domEventsInfo.set(listenerElement, [eventType]);
    } else {
      domEventsInfo.get(listenerElement).push(eventType);
    }
  }
  return domEventsInfo;
}
function invokeRegisteredReplayListeners(injector, event, currentTarget) {
  const blockName = (currentTarget && currentTarget.getAttribute(DEFER_BLOCK_SSR_ID_ATTRIBUTE)) ?? '';
  if (/d\d+/.test(blockName)) {
    hydrateAndInvokeBlockListeners(blockName, injector, event, currentTarget);
  } else if (event.eventPhase === EventPhase.REPLAY) {
    invokeListeners(event, currentTarget);
  }
}
function hydrateAndInvokeBlockListeners(blockName, injector, event, currentTarget) {
  const queue = injector.get(EVENT_REPLAY_QUEUE);
  queue.push({
    event,
    currentTarget
  });
  triggerHydrationFromBlockName(injector, blockName, createReplayQueuedBlockEventsFn(queue));
}
function createReplayQueuedBlockEventsFn(queue) {
  return hydratedBlocks => {
    const hydrated = new Set(hydratedBlocks);
    const newQueue = [];
    for (let {
      event,
      currentTarget
    } of queue) {
      const blockName = currentTarget.getAttribute(DEFER_BLOCK_SSR_ID_ATTRIBUTE);
      if (hydrated.has(blockName)) {
        invokeListeners(event, currentTarget);
      } else {
        newQueue.push({
          event,
          currentTarget
        });
      }
    }
    queue.length = 0;
    queue.push(...newQueue);
  };
}

let isHydrationSupportEnabled = false;
let isI18nHydrationRuntimeSupportEnabled = false;
const APPLICATION_IS_STABLE_TIMEOUT = 10_000;
function enableHydrationRuntimeSupport() {
  if (!isHydrationSupportEnabled) {
    isHydrationSupportEnabled = true;
    enableRetrieveHydrationInfoImpl();
    enableLocateOrCreateElementNodeImpl();
    enableLocateOrCreateTextNodeImpl();
    enableLocateOrCreateElementContainerNodeImpl();
    enableLocateOrCreateContainerAnchorImpl();
    enableLocateOrCreateContainerRefImpl();
    enableFindMatchingDehydratedViewImpl();
    enableApplyRootElementTransformImpl();
  }
}
function enableI18nHydrationRuntimeSupport() {
  if (!isI18nHydrationRuntimeSupportEnabled) {
    isI18nHydrationRuntimeSupportEnabled = true;
    enableLocateOrCreateI18nNodeImpl();
    enablePrepareI18nBlockForHydrationImpl();
    enableClaimDehydratedIcuCaseImpl();
  }
}
function printHydrationStats(injector) {
  const console = injector.get(Console);
  const message = `Angular hydrated ${ngDevMode.hydratedComponents} component(s) ` + `and ${ngDevMode.hydratedNodes} node(s), ` + `${ngDevMode.componentsSkippedHydration} component(s) were skipped. ` + (isIncrementalHydrationEnabled(injector) ? `${ngDevMode.deferBlocksWithIncrementalHydration} defer block(s) were configured to use incremental hydration. ` : '') + `Learn more at ${DOC_PAGE_BASE_URL}/guide/hydration.`;
  console.log(message);
}
function whenStableWithTimeout(appRef) {
  const whenStablePromise = appRef.whenStable();
  if (typeof ngDevMode !== 'undefined' && ngDevMode) {
    const timeoutTime = APPLICATION_IS_STABLE_TIMEOUT;
    const console = appRef.injector.get(Console);
    const ngZone = appRef.injector.get(NgZone);
    const timeoutId = ngZone.runOutsideAngular(() => {
      return setTimeout(() => logWarningOnStableTimedout(timeoutTime, console), timeoutTime);
    });
    whenStablePromise.finally(() => clearTimeout(timeoutId));
  }
  return whenStablePromise;
}
const CLIENT_RENDER_MODE_FLAG = 'ngcm';
function isClientRenderModeEnabled(doc) {
  return (typeof ngServerMode === 'undefined' || !ngServerMode) && doc.body.hasAttribute(CLIENT_RENDER_MODE_FLAG);
}
function withDomHydration() {
  const providers = [{
    provide: IS_HYDRATION_DOM_REUSE_ENABLED,
    useFactory: () => {
      let isEnabled = true;
      if (typeof ngServerMode === 'undefined' || !ngServerMode) {
        const transferState = inject(TransferState, {
          optional: true
        });
        isEnabled = !!transferState?.get(NGH_DATA_KEY, null);
      }
      if (isEnabled) {
        performanceMarkFeature('NgHydration');
      }
      return isEnabled;
    }
  }, {
    provide: ENVIRONMENT_INITIALIZER,
    useValue: () => {
      setIsI18nHydrationSupportEnabled(false);
      if (typeof ngServerMode !== 'undefined' && ngServerMode) {
        return;
      }
      const doc = inject(DOCUMENT);
      if (inject(IS_HYDRATION_DOM_REUSE_ENABLED)) {
        verifySsrContentsIntegrity(doc);
        enableHydrationRuntimeSupport();
      } else if (typeof ngDevMode !== 'undefined' && ngDevMode && !isClientRenderModeEnabled(doc)) {
        const console = inject(Console);
        const message = formatRuntimeError(-505, 'Angular hydration was requested on the client, but there was no ' + 'serialized information present in the server response, ' + 'thus hydration was not enabled. ' + 'Make sure the `provideClientHydration()` is included into the list ' + 'of providers in the server part of the application configuration.');
        console.warn(message);
      }
    },
    multi: true
  }];
  if (typeof ngServerMode === 'undefined' || !ngServerMode) {
    providers.push({
      provide: PRESERVE_HOST_CONTENT,
      useFactory: () => {
        return inject(IS_HYDRATION_DOM_REUSE_ENABLED);
      }
    }, {
      provide: APP_BOOTSTRAP_LISTENER,
      useFactory: () => {
        const scheduler = inject(ChangeDetectionScheduler);
        if (inject(IS_HYDRATION_DOM_REUSE_ENABLED)) {
          const appRef = inject(ApplicationRef);
          return () => {
            whenStableWithTimeout(appRef).then(() => {
              if (appRef.destroyed) {
                return;
              }
              cleanupDehydratedViews(appRef);
              if (typeof ngDevMode !== 'undefined' && ngDevMode) {
                countBlocksSkippedByHydration(appRef.injector);
                printHydrationStats(appRef.injector);
              }
              scheduler.notify(7);
            });
          };
        }
        return () => {};
      },
      multi: true
    });
  }
  return makeEnvironmentProviders(providers);
}
function withI18nSupport() {
  return [{
    provide: IS_I18N_HYDRATION_ENABLED,
    useFactory: () => inject(IS_HYDRATION_DOM_REUSE_ENABLED)
  }, {
    provide: ENVIRONMENT_INITIALIZER,
    useValue: () => {
      if (inject(IS_HYDRATION_DOM_REUSE_ENABLED)) {
        enableI18nHydrationRuntimeSupport();
        setIsI18nHydrationSupportEnabled(true);
        performanceMarkFeature('NgI18nHydration');
      }
    },
    multi: true
  }];
}
function withIncrementalHydration() {
  const providers = [withEventReplay(), {
    provide: IS_INCREMENTAL_HYDRATION_ENABLED,
    useValue: true
  }, {
    provide: DEHYDRATED_BLOCK_REGISTRY,
    useFactory: createDehydratedBlockRegistry
  }];
  if (typeof ngServerMode === 'undefined' || !ngServerMode) {
    providers.push({
      provide: INCREMENTAL_HYDRATION_BOOTSTRAP,
      useFactory: () => ({
        requested: false,
        activated: false,
        injector: inject(Injector),
        document: inject(DOCUMENT)
      })
    }, {
      provide: APP_BOOTSTRAP_LISTENER,
      useFactory: () => {
        const state = inject(INCREMENTAL_HYDRATION_BOOTSTRAP);
        return () => {
          if (!state.requested) {
            state.requested = true;
            runIncrementalHydrationBootstrap(state);
          }
        };
      },
      multi: true
    });
  }
  return providers;
}
function logWarningOnStableTimedout(time, console) {
  const message = `Angular hydration expected the ApplicationRef.isStable() to emit \`true\`, but it ` + `didn't happen within ${time}ms. Angular hydration logic depends on the application becoming stable ` + `as a signal to complete hydration process.`;
  console.warn(formatRuntimeError(-506, message));
}

const STABILITY_WARNING_THRESHOLD = APPLICATION_IS_STABLE_TIMEOUT - 1_000;
class DebugTaskTrackerImpl {
  openTasks = new Map();
  add(taskId) {
    this.openTasks.set(taskId, new Error('Task stack tracking error'));
  }
  remove(taskId) {
    this.openTasks.delete(taskId);
  }
}
function provideStabilityDebugging() {
  const taskTracker = new DebugTaskTrackerImpl();
  const {
    openTasks
  } = taskTracker;
  return makeEnvironmentProviders([{
    provide: DEBUG_TASK_TRACKER,
    useValue: taskTracker
  }, provideAppInitializer(() => {
    if (typeof ngDevMode === 'undefined' || !ngDevMode) {
      console.warn('Stability debugging utility was provided in production mode. ' + 'This will cause debug code to be included in production bundles. ' + 'If this is intentional because you are debugging stability issues in a production environment, you can ignore this warning.');
    }
    const ngZone = inject(NgZone);
    const applicationRef = inject(ApplicationRef);
    let _taskTrackingZone = null;
    if (typeof Zone !== 'undefined') {
      ngZone.run(() => {
        _taskTrackingZone = Zone.current.get('TaskTrackingZone');
      });
    }
    ngZone.runOutsideAngular(() => {
      const timeoutId = setTimeout(() => {
        console.debug(`---- Application did not stabilize within ${STABILITY_WARNING_THRESHOLD / 1000} seconds ----`);
        if (typeof Zone !== 'undefined' && !_taskTrackingZone) {
          console.info('Zone.js is present but no TaskTrackingZone found. To enable better debugging of tasks in the Angular Zone, ' + 'import "zone.js/plugins/task-tracking" in your application.');
        }
        if (_taskTrackingZone?.macroTasks?.length) {
          console.group('Macrotasks keeping Angular Zone unstable:');
          for (const t of _taskTrackingZone?.macroTasks ?? []) {
            console.debug(t.creationLocation.stack);
          }
          console.groupEnd();
        }
        console.group('PendingTasks keeping application unstable:');
        for (const error of openTasks.values()) {
          console.debug(error.stack);
        }
        console.groupEnd();
      }, STABILITY_WARNING_THRESHOLD);
      applicationRef.whenStable().then(() => {
        clearTimeout(timeoutId);
      });
    });
  })]);
}

class DefaultIterableDifferFactory {
  supports(obj) {
    return isListLikeIterable(obj);
  }
  create(trackByFn) {
    return new DefaultIterableDiffer(trackByFn);
  }
}
const trackByIdentity = (index, item) => item;
class DefaultIterableDiffer {
  length = 0;
  collection;
  _linkedRecords = null;
  _unlinkedRecords = null;
  _previousItHead = null;
  _itHead = null;
  _itTail = null;
  _additionsHead = null;
  _additionsTail = null;
  _movesHead = null;
  _movesTail = null;
  _removalsHead = null;
  _removalsTail = null;
  _identityChangesHead = null;
  _identityChangesTail = null;
  _trackByFn;
  constructor(trackByFn) {
    this._trackByFn = trackByFn || trackByIdentity;
  }
  forEachItem(fn) {
    let record;
    for (record = this._itHead; record !== null; record = record._next) {
      fn(record);
    }
  }
  forEachOperation(fn) {
    let nextIt = this._itHead;
    let nextRemove = this._removalsHead;
    let addRemoveOffset = 0;
    let moveOffsets = null;
    while (nextIt || nextRemove) {
      const record = !nextRemove || nextIt && nextIt.currentIndex < getPreviousIndex(nextRemove, addRemoveOffset, moveOffsets) ? nextIt : nextRemove;
      const adjPreviousIndex = getPreviousIndex(record, addRemoveOffset, moveOffsets);
      const currentIndex = record.currentIndex;
      if (record === nextRemove) {
        addRemoveOffset--;
        nextRemove = nextRemove._nextRemoved;
      } else {
        nextIt = nextIt._next;
        if (record.previousIndex == null) {
          addRemoveOffset++;
        } else {
          if (!moveOffsets) moveOffsets = [];
          const localMovePreviousIndex = adjPreviousIndex - addRemoveOffset;
          const localCurrentIndex = currentIndex - addRemoveOffset;
          if (localMovePreviousIndex != localCurrentIndex) {
            for (let i = 0; i < localMovePreviousIndex; i++) {
              const offset = i < moveOffsets.length ? moveOffsets[i] : moveOffsets[i] = 0;
              const index = offset + i;
              if (localCurrentIndex <= index && index < localMovePreviousIndex) {
                moveOffsets[i] = offset + 1;
              }
            }
            const previousIndex = record.previousIndex;
            moveOffsets[previousIndex] = localCurrentIndex - localMovePreviousIndex;
          }
        }
      }
      if (adjPreviousIndex !== currentIndex) {
        fn(record, adjPreviousIndex, currentIndex);
      }
    }
  }
  forEachPreviousItem(fn) {
    let record;
    for (record = this._previousItHead; record !== null; record = record._nextPrevious) {
      fn(record);
    }
  }
  forEachAddedItem(fn) {
    let record;
    for (record = this._additionsHead; record !== null; record = record._nextAdded) {
      fn(record);
    }
  }
  forEachMovedItem(fn) {
    let record;
    for (record = this._movesHead; record !== null; record = record._nextMoved) {
      fn(record);
    }
  }
  forEachRemovedItem(fn) {
    let record;
    for (record = this._removalsHead; record !== null; record = record._nextRemoved) {
      fn(record);
    }
  }
  forEachIdentityChange(fn) {
    let record;
    for (record = this._identityChangesHead; record !== null; record = record._nextIdentityChange) {
      fn(record);
    }
  }
  diff(collection) {
    if (collection == null) collection = [];
    if (!isListLikeIterable(collection)) {
      throw new RuntimeError(900, ngDevMode && `Error trying to diff '${stringify(collection)}'. Only arrays and iterables are allowed`);
    }
    if (this.check(collection)) {
      return this;
    } else {
      return null;
    }
  }
  onDestroy() {}
  check(collection) {
    this._reset();
    let record = this._itHead;
    let mayBeDirty = false;
    let index;
    let item;
    let itemTrackBy;
    if (Array.isArray(collection)) {
      this.length = collection.length;
      for (let index = 0; index < this.length; index++) {
        item = collection[index];
        itemTrackBy = this._trackByFn(index, item);
        if (record === null || !Object.is(record.trackById, itemTrackBy)) {
          record = this._mismatch(record, item, itemTrackBy, index);
          mayBeDirty = true;
        } else {
          if (mayBeDirty) {
            record = this._verifyReinsertion(record, item, itemTrackBy, index);
          }
          if (!Object.is(record.item, item)) this._addIdentityChange(record, item);
        }
        record = record._next;
      }
    } else {
      index = 0;
      iterateListLike(collection, item => {
        itemTrackBy = this._trackByFn(index, item);
        if (record === null || !Object.is(record.trackById, itemTrackBy)) {
          record = this._mismatch(record, item, itemTrackBy, index);
          mayBeDirty = true;
        } else {
          if (mayBeDirty) {
            record = this._verifyReinsertion(record, item, itemTrackBy, index);
          }
          if (!Object.is(record.item, item)) this._addIdentityChange(record, item);
        }
        record = record._next;
        index++;
      });
      this.length = index;
    }
    this._truncate(record);
    this.collection = collection;
    return this.isDirty;
  }
  get isDirty() {
    return this._additionsHead !== null || this._movesHead !== null || this._removalsHead !== null || this._identityChangesHead !== null;
  }
  _reset() {
    if (this.isDirty) {
      let record;
      for (record = this._previousItHead = this._itHead; record !== null; record = record._next) {
        record._nextPrevious = record._next;
      }
      for (record = this._additionsHead; record !== null; record = record._nextAdded) {
        record.previousIndex = record.currentIndex;
      }
      this._additionsHead = this._additionsTail = null;
      for (record = this._movesHead; record !== null; record = record._nextMoved) {
        record.previousIndex = record.currentIndex;
      }
      this._movesHead = this._movesTail = null;
      this._removalsHead = this._removalsTail = null;
      this._identityChangesHead = this._identityChangesTail = null;
    }
  }
  _mismatch(record, item, itemTrackBy, index) {
    let previousRecord;
    if (record === null) {
      previousRecord = this._itTail;
    } else {
      previousRecord = record._prev;
      this._remove(record);
    }
    record = this._unlinkedRecords === null ? null : this._unlinkedRecords.get(itemTrackBy, null);
    if (record !== null) {
      if (!Object.is(record.item, item)) this._addIdentityChange(record, item);
      this._reinsertAfter(record, previousRecord, index);
    } else {
      record = this._linkedRecords === null ? null : this._linkedRecords.get(itemTrackBy, index);
      if (record !== null) {
        if (!Object.is(record.item, item)) this._addIdentityChange(record, item);
        this._moveAfter(record, previousRecord, index);
      } else {
        record = this._addAfter(new IterableChangeRecord_(item, itemTrackBy), previousRecord, index);
      }
    }
    return record;
  }
  _verifyReinsertion(record, item, itemTrackBy, index) {
    let reinsertRecord = this._unlinkedRecords === null ? null : this._unlinkedRecords.get(itemTrackBy, null);
    if (reinsertRecord !== null) {
      record = this._reinsertAfter(reinsertRecord, record._prev, index);
    } else if (record.currentIndex != index) {
      record.currentIndex = index;
      this._addToMoves(record, index);
    }
    return record;
  }
  _truncate(record) {
    while (record !== null) {
      const nextRecord = record._next;
      this._addToRemovals(this._unlink(record));
      record = nextRecord;
    }
    if (this._unlinkedRecords !== null) {
      this._unlinkedRecords.clear();
    }
    if (this._additionsTail !== null) {
      this._additionsTail._nextAdded = null;
    }
    if (this._movesTail !== null) {
      this._movesTail._nextMoved = null;
    }
    if (this._itTail !== null) {
      this._itTail._next = null;
    }
    if (this._removalsTail !== null) {
      this._removalsTail._nextRemoved = null;
    }
    if (this._identityChangesTail !== null) {
      this._identityChangesTail._nextIdentityChange = null;
    }
  }
  _reinsertAfter(record, prevRecord, index) {
    if (this._unlinkedRecords !== null) {
      this._unlinkedRecords.remove(record);
    }
    const prev = record._prevRemoved;
    const next = record._nextRemoved;
    if (prev === null) {
      this._removalsHead = next;
    } else {
      prev._nextRemoved = next;
    }
    if (next === null) {
      this._removalsTail = prev;
    } else {
      next._prevRemoved = prev;
    }
    this._insertAfter(record, prevRecord, index);
    this._addToMoves(record, index);
    return record;
  }
  _moveAfter(record, prevRecord, index) {
    this._unlink(record);
    this._insertAfter(record, prevRecord, index);
    this._addToMoves(record, index);
    return record;
  }
  _addAfter(record, prevRecord, index) {
    this._insertAfter(record, prevRecord, index);
    if (this._additionsTail === null) {
      this._additionsTail = this._additionsHead = record;
    } else {
      this._additionsTail = this._additionsTail._nextAdded = record;
    }
    return record;
  }
  _insertAfter(record, prevRecord, index) {
    const next = prevRecord === null ? this._itHead : prevRecord._next;
    record._next = next;
    record._prev = prevRecord;
    if (next === null) {
      this._itTail = record;
    } else {
      next._prev = record;
    }
    if (prevRecord === null) {
      this._itHead = record;
    } else {
      prevRecord._next = record;
    }
    if (this._linkedRecords === null) {
      this._linkedRecords = new _DuplicateMap();
    }
    this._linkedRecords.put(record);
    record.currentIndex = index;
    return record;
  }
  _remove(record) {
    return this._addToRemovals(this._unlink(record));
  }
  _unlink(record) {
    if (this._linkedRecords !== null) {
      this._linkedRecords.remove(record);
    }
    const prev = record._prev;
    const next = record._next;
    if (prev === null) {
      this._itHead = next;
    } else {
      prev._next = next;
    }
    if (next === null) {
      this._itTail = prev;
    } else {
      next._prev = prev;
    }
    return record;
  }
  _addToMoves(record, toIndex) {
    if (record.previousIndex === toIndex) {
      return record;
    }
    if (this._movesTail === null) {
      this._movesTail = this._movesHead = record;
    } else {
      this._movesTail = this._movesTail._nextMoved = record;
    }
    return record;
  }
  _addToRemovals(record) {
    if (this._unlinkedRecords === null) {
      this._unlinkedRecords = new _DuplicateMap();
    }
    this._unlinkedRecords.put(record);
    record.currentIndex = null;
    record._nextRemoved = null;
    if (this._removalsTail === null) {
      this._removalsTail = this._removalsHead = record;
      record._prevRemoved = null;
    } else {
      record._prevRemoved = this._removalsTail;
      this._removalsTail = this._removalsTail._nextRemoved = record;
    }
    return record;
  }
  _addIdentityChange(record, item) {
    record.item = item;
    if (this._identityChangesTail === null) {
      this._identityChangesTail = this._identityChangesHead = record;
    } else {
      this._identityChangesTail = this._identityChangesTail._nextIdentityChange = record;
    }
    return record;
  }
}
class IterableChangeRecord_ {
  item;
  trackById;
  currentIndex = null;
  previousIndex = null;
  _nextPrevious = null;
  _prev = null;
  _next = null;
  _prevDup = null;
  _nextDup = null;
  _prevRemoved = null;
  _nextRemoved = null;
  _nextAdded = null;
  _nextMoved = null;
  _nextIdentityChange = null;
  constructor(item, trackById) {
    this.item = item;
    this.trackById = trackById;
  }
}
class _DuplicateItemRecordList {
  _head = null;
  _tail = null;
  add(record) {
    if (this._head === null) {
      this._head = this._tail = record;
      record._nextDup = null;
      record._prevDup = null;
    } else {
      this._tail._nextDup = record;
      record._prevDup = this._tail;
      record._nextDup = null;
      this._tail = record;
    }
  }
  get(trackById, atOrAfterIndex) {
    let record;
    for (record = this._head; record !== null; record = record._nextDup) {
      if ((atOrAfterIndex === null || atOrAfterIndex <= record.currentIndex) && Object.is(record.trackById, trackById)) {
        return record;
      }
    }
    return null;
  }
  remove(record) {
    const prev = record._prevDup;
    const next = record._nextDup;
    if (prev === null) {
      this._head = next;
    } else {
      prev._nextDup = next;
    }
    if (next === null) {
      this._tail = prev;
    } else {
      next._prevDup = prev;
    }
    return this._head === null;
  }
}
class _DuplicateMap {
  map = new Map();
  put(record) {
    const key = record.trackById;
    let duplicates = this.map.get(key);
    if (!duplicates) {
      duplicates = new _DuplicateItemRecordList();
      this.map.set(key, duplicates);
    }
    duplicates.add(record);
  }
  get(trackById, atOrAfterIndex) {
    const key = trackById;
    const recordList = this.map.get(key);
    return recordList ? recordList.get(trackById, atOrAfterIndex) : null;
  }
  remove(record) {
    const key = record.trackById;
    const recordList = this.map.get(key);
    if (recordList.remove(record)) {
      this.map.delete(key);
    }
    return record;
  }
  get isEmpty() {
    return this.map.size === 0;
  }
  clear() {
    this.map.clear();
  }
}
function getPreviousIndex(item, addRemoveOffset, moveOffsets) {
  const previousIndex = item.previousIndex;
  if (previousIndex === null) return previousIndex;
  let moveOffset = 0;
  if (moveOffsets && previousIndex < moveOffsets.length) {
    moveOffset = moveOffsets[previousIndex];
  }
  return previousIndex + addRemoveOffset + moveOffset;
}

class DefaultKeyValueDifferFactory {
  supports(obj) {
    return obj instanceof Map || isJsObject(obj);
  }
  create() {
    return new DefaultKeyValueDiffer();
  }
}
class DefaultKeyValueDiffer {
  _records = new Map();
  _mapHead = null;
  _appendAfter = null;
  _previousMapHead = null;
  _changesHead = null;
  _changesTail = null;
  _additionsHead = null;
  _additionsTail = null;
  _removalsHead = null;
  get isDirty() {
    return this._additionsHead !== null || this._changesHead !== null || this._removalsHead !== null;
  }
  forEachItem(fn) {
    let record;
    for (record = this._mapHead; record !== null; record = record._next) {
      fn(record);
    }
  }
  forEachPreviousItem(fn) {
    let record;
    for (record = this._previousMapHead; record !== null; record = record._nextPrevious) {
      fn(record);
    }
  }
  forEachChangedItem(fn) {
    let record;
    for (record = this._changesHead; record !== null; record = record._nextChanged) {
      fn(record);
    }
  }
  forEachAddedItem(fn) {
    let record;
    for (record = this._additionsHead; record !== null; record = record._nextAdded) {
      fn(record);
    }
  }
  forEachRemovedItem(fn) {
    let record;
    for (record = this._removalsHead; record !== null; record = record._nextRemoved) {
      fn(record);
    }
  }
  diff(map) {
    if (!map) {
      map = new Map();
    } else if (!(map instanceof Map || isJsObject(map))) {
      throw new RuntimeError(900, ngDevMode && `Error trying to diff '${stringify(map)}'. Only maps and objects are allowed`);
    }
    return this.check(map) ? this : null;
  }
  check(map) {
    this._reset();
    let insertBefore = this._mapHead;
    this._appendAfter = null;
    this._forEach(map, (value, key) => {
      if (insertBefore && insertBefore.key === key) {
        this._maybeAddToChanges(insertBefore, value);
        this._appendAfter = insertBefore;
        insertBefore = insertBefore._next;
      } else {
        const record = this._getOrCreateRecordForKey(key, value);
        insertBefore = this._insertBeforeOrAppend(insertBefore, record);
      }
    });
    if (insertBefore) {
      if (insertBefore._prev) {
        insertBefore._prev._next = null;
      }
      this._removalsHead = insertBefore;
      for (let record = insertBefore; record !== null; record = record._nextRemoved) {
        if (record === this._mapHead) {
          this._mapHead = null;
        }
        this._records.delete(record.key);
        record._nextRemoved = record._next;
        record.previousValue = record.currentValue;
        record.currentValue = null;
        record._prev = null;
        record._next = null;
      }
    }
    if (this._changesTail) this._changesTail._nextChanged = null;
    if (this._additionsTail) this._additionsTail._nextAdded = null;
    return this.isDirty;
  }
  _insertBeforeOrAppend(before, record) {
    if (before) {
      const prev = before._prev;
      record._next = before;
      record._prev = prev;
      before._prev = record;
      if (prev) {
        prev._next = record;
      }
      if (before === this._mapHead) {
        this._mapHead = record;
      }
      this._appendAfter = before;
      return before;
    }
    if (this._appendAfter) {
      this._appendAfter._next = record;
      record._prev = this._appendAfter;
    } else {
      this._mapHead = record;
    }
    this._appendAfter = record;
    return null;
  }
  _getOrCreateRecordForKey(key, value) {
    if (this._records.has(key)) {
      const record = this._records.get(key);
      this._maybeAddToChanges(record, value);
      const prev = record._prev;
      const next = record._next;
      if (prev) {
        prev._next = next;
      }
      if (next) {
        next._prev = prev;
      }
      record._next = null;
      record._prev = null;
      return record;
    }
    const record = new KeyValueChangeRecord_(key);
    this._records.set(key, record);
    record.currentValue = value;
    this._addToAdditions(record);
    return record;
  }
  _reset() {
    if (this.isDirty) {
      let record;
      this._previousMapHead = this._mapHead;
      for (record = this._previousMapHead; record !== null; record = record._next) {
        record._nextPrevious = record._next;
      }
      for (record = this._changesHead; record !== null; record = record._nextChanged) {
        record.previousValue = record.currentValue;
      }
      for (record = this._additionsHead; record != null; record = record._nextAdded) {
        record.previousValue = record.currentValue;
      }
      this._changesHead = this._changesTail = null;
      this._additionsHead = this._additionsTail = null;
      this._removalsHead = null;
    }
  }
  _maybeAddToChanges(record, newValue) {
    if (!Object.is(newValue, record.currentValue)) {
      record.previousValue = record.currentValue;
      record.currentValue = newValue;
      this._addToChanges(record);
    }
  }
  _addToAdditions(record) {
    if (this._additionsHead === null) {
      this._additionsHead = this._additionsTail = record;
    } else {
      this._additionsTail._nextAdded = record;
      this._additionsTail = record;
    }
  }
  _addToChanges(record) {
    if (this._changesHead === null) {
      this._changesHead = this._changesTail = record;
    } else {
      this._changesTail._nextChanged = record;
      this._changesTail = record;
    }
  }
  _forEach(obj, fn) {
    if (obj instanceof Map) {
      obj.forEach(fn);
    } else {
      Object.keys(obj).forEach(k => fn(obj[k], k));
    }
  }
}
class KeyValueChangeRecord_ {
  key;
  previousValue = null;
  currentValue = null;
  _nextPrevious = null;
  _next = null;
  _prev = null;
  _nextAdded = null;
  _nextRemoved = null;
  _nextChanged = null;
  constructor(key) {
    this.key = key;
  }
}

function defaultIterableDiffersFactory() {
  return new IterableDiffers([new DefaultIterableDifferFactory()]);
}
class IterableDiffers {
  factories;
  static ɵprov =
  /* @__PURE__ */
  __defineInjectable({
    token: IterableDiffers,
    providedIn: 'root',
    factory: defaultIterableDiffersFactory
  });
  constructor(factories) {
    this.factories = factories;
  }
  static create(factories, parent) {
    if (parent != null) {
      const copied = parent.factories.slice();
      factories = factories.concat(copied);
    }
    return new IterableDiffers(factories);
  }
  static extend(factories) {
    return {
      provide: IterableDiffers,
      useFactory: () => {
        const parent = inject(IterableDiffers, {
          optional: true,
          skipSelf: true
        });
        return IterableDiffers.create(factories, parent || defaultIterableDiffersFactory());
      }
    };
  }
  find(iterable) {
    const factory = this.factories.find(f => f.supports(iterable));
    if (factory != null) {
      return factory;
    } else {
      throw new RuntimeError(901, ngDevMode && `Cannot find a differ supporting object '${iterable}' of type '${getTypeNameForDebugging(iterable)}'`);
    }
  }
}
function getTypeNameForDebugging(type) {
  return type['name'] || typeof type;
}

function defaultKeyValueDiffersFactory() {
  return new KeyValueDiffers([new DefaultKeyValueDifferFactory()]);
}
class KeyValueDiffers {
  static ɵprov =
  /* @__PURE__ */
  __defineInjectable({
    token: KeyValueDiffers,
    providedIn: 'root',
    factory: defaultKeyValueDiffersFactory
  });
  factories;
  constructor(factories) {
    this.factories = factories;
  }
  static create(factories, parent) {
    if (parent) {
      const copied = parent.factories.slice();
      factories = factories.concat(copied);
    }
    return new KeyValueDiffers(factories);
  }
  static extend(factories) {
    return {
      provide: KeyValueDiffers,
      useFactory: () => {
        const parent = inject(KeyValueDiffers, {
          optional: true,
          skipSelf: true
        });
        return KeyValueDiffers.create(factories, parent || defaultKeyValueDiffersFactory());
      }
    };
  }
  find(kv) {
    const factory = this.factories.find(f => f.supports(kv));
    if (factory) {
      return factory;
    }
    throw new RuntimeError(901, ngDevMode && `Cannot find a differ supporting object '${kv}'`);
  }
}

class ChangeDetectorRef {
  static __NG_ELEMENT_ID__ = injectChangeDetectorRef;
}
if (typeof ngDevMode === 'undefined' || ngDevMode) {
  registerSpecialProvider(ChangeDetectorRef);
}
function injectChangeDetectorRef(flags) {
  return createViewRef(getCurrentTNode(), getLView(), (flags & 16) === 16);
}
function createViewRef(tNode, lView, isPipe) {
  if (isComponentHost(tNode) && !isPipe) {
    const componentView = getComponentLViewByIndex(tNode.index, lView);
    return new ViewRef$1(componentView, componentView);
  } else if (tNode.type & (3 | 12 | 32 | 128)) {
    const hostComponentView = lView[DECLARATION_COMPONENT_VIEW];
    return new ViewRef$1(hostComponentView, lView);
  }
  return null;
}

const keyValDiff = [new DefaultKeyValueDifferFactory()];
const iterableDiff = [new DefaultIterableDifferFactory()];
const defaultIterableDiffers = new IterableDiffers(iterableDiff);
const defaultKeyValueDiffers = new KeyValueDiffers(keyValDiff);

function exhaustiveCheckNoChangesInterval(interval) {
  return provideEnvironmentInitializer(() => {
    const applicationRef = inject(ApplicationRef);
    const errorHandler = inject(ErrorHandler);
    const scheduler = inject(ChangeDetectionSchedulerImpl);
    const ngZone = inject(NgZone);
    function scheduleCheckNoChanges() {
      ngZone.runOutsideAngular(() => {
        setTimeout(() => {
          if (applicationRef.destroyed) {
            return;
          }
          if (scheduler.pendingRenderTaskId || scheduler.runningTick) {
            scheduleCheckNoChanges();
            return;
          }
          for (const view of applicationRef.allViews) {
            try {
              checkNoChangesInternal(view._lView, true);
            } catch (e) {
              errorHandler.handleError(e);
            }
          }
          scheduleCheckNoChanges();
        }, interval);
      });
    }
    scheduleCheckNoChanges();
  });
}

function provideCheckNoChangesConfig(options) {
  return makeEnvironmentProviders(typeof ngDevMode === 'undefined' || ngDevMode ? [{
    provide: UseExhaustiveCheckNoChanges,
    useValue: options.exhaustive
  }, options?.interval !== undefined ? exhaustiveCheckNoChangesInterval(options.interval) : []] : []);
}

class NgZoneChangeDetectionScheduler {
  zone = inject(NgZone);
  changeDetectionScheduler = inject(ChangeDetectionScheduler);
  applicationRef = inject(ApplicationRef);
  applicationErrorHandler = inject(INTERNAL_APPLICATION_ERROR_HANDLER);
  _onMicrotaskEmptySubscription;
  initialize() {
    if (this._onMicrotaskEmptySubscription) {
      return;
    }
    this._onMicrotaskEmptySubscription = this.zone.onMicrotaskEmpty.subscribe({
      next: () => {
        if (this.changeDetectionScheduler.runningTick) {
          return;
        }
        this.zone.run(() => {
          try {
            this.applicationRef.dirtyFlags |= 1;
            this.applicationRef._tick();
          } catch (e) {
            this.applicationErrorHandler(e);
          }
        });
      }
    });
  }
  ngOnDestroy() {
    this._onMicrotaskEmptySubscription?.unsubscribe();
  }
  static ɵfac = function NgZoneChangeDetectionScheduler_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || NgZoneChangeDetectionScheduler)();
  };
  static ɵprov = /*@__PURE__*/__defineService({
    token: NgZoneChangeDetectionScheduler,
    factory: NgZoneChangeDetectionScheduler.ɵfac
  });
}
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgZoneChangeDetectionScheduler, [{
    type: Service
  }], null, null);
})();
const PROVIDED_NG_ZONE = new InjectionToken(typeof ngDevMode === 'undefined' || ngDevMode ? 'provideZoneChangeDetection token' : '', {
  factory: () => false
});
function internalProvideZoneChangeDetection({
  ngZoneFactory,
  scheduleInRootZone
}) {
  ngZoneFactory ??= () => new NgZone({
    ...getNgZoneOptions(),
    scheduleInRootZone
  });
  return [{
    provide: ZONELESS_ENABLED,
    useValue: false
  }, {
    provide: NgZone,
    useFactory: ngZoneFactory
  }, {
    provide: ENVIRONMENT_INITIALIZER,
    multi: true,
    useFactory: () => {
      const ngZoneChangeDetectionScheduler = inject(NgZoneChangeDetectionScheduler, {
        optional: true
      });
      if ((typeof ngDevMode === 'undefined' || ngDevMode) && ngZoneChangeDetectionScheduler === null) {
        throw new RuntimeError(402, `A required Injectable was not found in the dependency injection tree. ` + 'If you are bootstrapping an NgModule, make sure that the `BrowserModule` is imported.');
      }
      return () => ngZoneChangeDetectionScheduler.initialize();
    }
  }, {
    provide: ENVIRONMENT_INITIALIZER,
    multi: true,
    useFactory: () => {
      const service = inject(ZoneStablePendingTask);
      return () => {
        service.initialize();
      };
    }
  }, {
    provide: SCHEDULE_IN_ROOT_ZONE,
    useValue: scheduleInRootZone ?? SCHEDULE_IN_ROOT_ZONE_DEFAULT
  }];
}
function provideZoneChangeDetection(options) {
  const scheduleInRootZone = options?.scheduleInRootZone;
  const zoneProviders = internalProvideZoneChangeDetection({
    ngZoneFactory: () => {
      const ngZoneOptions = getNgZoneOptions(options);
      ngZoneOptions.scheduleInRootZone = scheduleInRootZone;
      if (ngZoneOptions.shouldCoalesceEventChangeDetection) {
        performanceMarkFeature('NgZone_CoalesceEvent');
      }
      return new NgZone(ngZoneOptions);
    },
    scheduleInRootZone
  });
  return makeEnvironmentProviders([{
    provide: PROVIDED_NG_ZONE,
    useValue: true
  }, zoneProviders]);
}
function getNgZoneOptions(options) {
  return {
    enableLongStackTrace: typeof ngDevMode === 'undefined' ? false : !!ngDevMode,
    shouldCoalesceEventChangeDetection: options?.eventCoalescing ?? false,
    shouldCoalesceRunChangeDetection: options?.runCoalescing ?? false
  };
}
class ZoneStablePendingTask {
  subscription = new Subscription();
  initialized = false;
  zone = inject(NgZone);
  pendingTasks = inject(PendingTasksInternal);
  initialize() {
    if (this.initialized) {
      return;
    }
    this.initialized = true;
    let task = null;
    if (!this.zone.isStable && !this.zone.hasPendingMacrotasks && !this.zone.hasPendingMicrotasks) {
      task = this.pendingTasks.add();
    }
    this.zone.runOutsideAngular(() => {
      this.subscription.add(this.zone.onStable.subscribe(() => {
        NgZone.assertNotInAngularZone();
        queueMicrotask(() => {
          if (task !== null && !this.zone.hasPendingMacrotasks && !this.zone.hasPendingMicrotasks) {
            this.pendingTasks.remove(task);
            task = null;
          }
        });
      }));
    });
    this.subscription.add(this.zone.onUnstable.subscribe(() => {
      NgZone.assertInAngularZone();
      task ??= this.pendingTasks.add();
    }));
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  static ɵfac = function ZoneStablePendingTask_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ZoneStablePendingTask)();
  };
  static ɵprov = /*@__PURE__*/__defineService({
    token: ZoneStablePendingTask,
    factory: ZoneStablePendingTask.ɵfac
  });
}
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ZoneStablePendingTask, [{
    type: Service
  }], null, null);
})();

function compileNgModuleFactory(injector, options, moduleType) {
  ngDevMode && assertNgModuleType(moduleType);
  const moduleFactory = new NgModuleFactory(moduleType);
  if (typeof ngJitMode !== 'undefined' && !ngJitMode) {
    return Promise.resolve(moduleFactory);
  }
  const compilerOptions = injector.get(COMPILER_OPTIONS, []).concat(options);
  setJitOptions({
    defaultEncapsulation: _lastDefined(compilerOptions.map(opts => opts.defaultEncapsulation)),
    preserveWhitespaces: _lastDefined(compilerOptions.map(opts => opts.preserveWhitespaces))
  });
  if (isComponentResourceResolutionQueueEmpty()) {
    return Promise.resolve(moduleFactory);
  }
  const compilerProviders = compilerOptions.flatMap(option => option.providers ?? []);
  if (compilerProviders.length === 0) {
    return Promise.resolve(moduleFactory);
  }
  const compiler = getCompilerFacade({
    usage: 0,
    kind: 'NgModule',
    type: moduleType
  });
  const compilerInjector = Injector.create({
    providers: compilerProviders
  });
  const resourceLoader = compilerInjector.get(compiler.ResourceLoader);
  return resolveComponentResources(url => Promise.resolve(resourceLoader.get(url))).then(() => moduleFactory);
}
function _lastDefined(args) {
  for (let i = args.length - 1; i >= 0; i--) {
    if (args[i] !== undefined) {
      return args[i];
    }
  }
  return undefined;
}

const SCAN_DELAY = 200;
const OVERSIZED_IMAGE_TOLERANCE = 1200;
class ImagePerformanceWarning {
  window = null;
  observer = null;
  options = inject(IMAGE_CONFIG);
  lcpImageUrl;
  start() {
    if (typeof ngServerMode !== 'undefined' && ngServerMode || typeof PerformanceObserver === 'undefined' || this.options?.disableImageSizeWarning && this.options?.disableImageLazyLoadWarning) {
      return;
    }
    this.observer = this.initPerformanceObserver();
    const doc = getDocument();
    const win = doc.defaultView;
    if (win) {
      this.window = win;
      const waitToScan = () => {
        setTimeout(this.scanImages.bind(this), SCAN_DELAY);
      };
      const setup = () => {
        if (doc.readyState === 'complete') {
          waitToScan();
        } else {
          this.window?.addEventListener('load', waitToScan, {
            once: true
          });
        }
      };
      if (typeof Zone !== 'undefined') {
        Zone.root.run(() => setup());
      } else {
        setup();
      }
    }
  }
  ngOnDestroy() {
    this.observer?.disconnect();
  }
  initPerformanceObserver() {
    if (typeof PerformanceObserver === 'undefined') {
      return null;
    }
    const observer = new PerformanceObserver(entryList => {
      const entries = entryList.getEntries();
      if (entries.length === 0) return;
      const lcpElement = entries[entries.length - 1];
      const imgSrc = lcpElement.element?.src ?? '';
      if (imgSrc.startsWith('data:') || imgSrc.startsWith('blob:')) return;
      this.lcpImageUrl = imgSrc;
    });
    observer.observe({
      type: 'largest-contentful-paint',
      buffered: true
    });
    return observer;
  }
  scanImages() {
    const images = getDocument().querySelectorAll('img');
    let lcpElementFound,
      lcpElementLoadedCorrectly = false;
    for (let index = 0; index < images.length; index++) {
      const image = images[index];
      if (!image) {
        continue;
      }
      if (!this.options?.disableImageSizeWarning) {
        if (!image.getAttribute('ng-img') && this.isOversized(image)) {
          logOversizedImageWarning(image.src);
        }
      }
      if (!this.options?.disableImageLazyLoadWarning && this.lcpImageUrl) {
        if (image.src === this.lcpImageUrl) {
          lcpElementFound = true;
          if (image.loading !== 'lazy' || image.getAttribute('ng-img')) {
            lcpElementLoadedCorrectly = true;
          }
        }
      }
    }
    if (lcpElementFound && !lcpElementLoadedCorrectly && this.lcpImageUrl && !this.options?.disableImageLazyLoadWarning) {
      logLazyLCPWarning(this.lcpImageUrl);
    }
  }
  isOversized(image) {
    if (!this.window) {
      return false;
    }
    const nonOversizedImageExtentions = ['.svg'];
    const imageSource = (image.src || '').toLowerCase();
    if (nonOversizedImageExtentions.some(extension => imageSource.endsWith(extension))) {
      return false;
    }
    const computedStyle = this.window.getComputedStyle(image);
    let renderedWidth = parseFloat(computedStyle.getPropertyValue('width'));
    let renderedHeight = parseFloat(computedStyle.getPropertyValue('height'));
    const boxSizing = computedStyle.getPropertyValue('box-sizing');
    const objectFit = computedStyle.getPropertyValue('object-fit');
    if (objectFit === `cover`) {
      return false;
    }
    if (boxSizing === 'border-box') {
      const paddingTop = computedStyle.getPropertyValue('padding-top');
      const paddingRight = computedStyle.getPropertyValue('padding-right');
      const paddingBottom = computedStyle.getPropertyValue('padding-bottom');
      const paddingLeft = computedStyle.getPropertyValue('padding-left');
      renderedWidth -= parseFloat(paddingRight) + parseFloat(paddingLeft);
      renderedHeight -= parseFloat(paddingTop) + parseFloat(paddingBottom);
    }
    const intrinsicWidth = image.naturalWidth;
    const intrinsicHeight = image.naturalHeight;
    const recommendedWidth = this.window.devicePixelRatio * renderedWidth;
    const recommendedHeight = this.window.devicePixelRatio * renderedHeight;
    const oversizedWidth = intrinsicWidth - recommendedWidth >= OVERSIZED_IMAGE_TOLERANCE;
    const oversizedHeight = intrinsicHeight - recommendedHeight >= OVERSIZED_IMAGE_TOLERANCE;
    return oversizedWidth || oversizedHeight;
  }
  static ɵfac = function ImagePerformanceWarning_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ImagePerformanceWarning)();
  };
  static ɵprov = /*@__PURE__*/__defineService({
    token: ImagePerformanceWarning,
    factory: ImagePerformanceWarning.ɵfac
  });
}
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ImagePerformanceWarning, [{
    type: Service
  }], null, null);
})();
function logLazyLCPWarning(src) {
  console.warn(formatRuntimeError(-913, `An image with src ${src} is the Largest Contentful Paint (LCP) element ` + `but was given a "loading" value of "lazy", which can negatively impact ` + `application loading performance. This warning can be addressed by ` + `changing the loading value of the LCP image to "eager", or by using the ` + `NgOptimizedImage directive's prioritization utilities. For more ` + `information about addressing or disabling this warning, see ` + `${ERROR_DETAILS_PAGE_BASE_URL}/NG0913`));
}
function logOversizedImageWarning(src) {
  console.warn(formatRuntimeError(-913, `An image with src ${src} has intrinsic file dimensions much larger than its ` + `rendered size. This can negatively impact application loading performance. ` + `For more information about addressing or disabling this warning, see ` + `${ERROR_DETAILS_PAGE_BASE_URL}/NG0913`));
}

const PLATFORM_DESTROY_LISTENERS = new InjectionToken(typeof ngDevMode !== 'undefined' && ngDevMode ? 'PlatformDestroyListeners' : '');

const ENABLE_ROOT_COMPONENT_BOOTSTRAP = new InjectionToken(typeof ngDevMode !== 'undefined' && ngDevMode ? 'ENABLE_ROOT_COMPONENT_BOOTSTRAP' : '');
function isApplicationBootstrapConfig(config) {
  return !config.moduleRef;
}
function bootstrap(config) {
  const envInjector = isApplicationBootstrapConfig(config) ? config.r3Injector : config.moduleRef.injector;
  const ngZone = envInjector.get(NgZone);
  return ngZone.run(() => {
    if (isApplicationBootstrapConfig(config)) {
      config.r3Injector.resolveInjectorInitializers();
    } else {
      config.moduleRef.resolveInjectorInitializers();
    }
    const exceptionHandler = envInjector.get(INTERNAL_APPLICATION_ERROR_HANDLER);
    if (typeof ngDevMode === 'undefined' || ngDevMode) {
      if (envInjector.get(PROVIDED_ZONELESS) && envInjector.get(PROVIDED_NG_ZONE)) {
        console.warn(formatRuntimeError(408, 'Both provideZoneChangeDetection and provideZonelessChangeDetection are provided. ' + 'This is likely a mistake. Update the application providers to use only one of the two.'));
      }
    }
    let onErrorSubscription;
    ngZone.runOutsideAngular(() => {
      onErrorSubscription = ngZone.onError.subscribe({
        next: exceptionHandler
      });
    });
    if (isApplicationBootstrapConfig(config)) {
      const destroyListener = () => envInjector.destroy();
      const onPlatformDestroyListeners = config.platformInjector.get(PLATFORM_DESTROY_LISTENERS);
      onPlatformDestroyListeners.add(destroyListener);
      envInjector.onDestroy(() => {
        onErrorSubscription.unsubscribe();
        onPlatformDestroyListeners.delete(destroyListener);
      });
    } else {
      const destroyListener = () => config.moduleRef.destroy();
      const onPlatformDestroyListeners = config.platformInjector.get(PLATFORM_DESTROY_LISTENERS);
      onPlatformDestroyListeners.add(destroyListener);
      config.moduleRef.onDestroy(() => {
        remove(config.allPlatformModules, config.moduleRef);
        onErrorSubscription.unsubscribe();
        onPlatformDestroyListeners.delete(destroyListener);
      });
    }
    return _callAndReportToErrorHandler(exceptionHandler, ngZone, () => {
      const pendingTasks = envInjector.get(PendingTasksInternal);
      const taskId = pendingTasks.add();
      const initStatus = envInjector.get(ApplicationInitStatus);
      initStatus.runInitializers();
      return initStatus.donePromise.then(() => {
        const localeId = envInjector.get(LOCALE_ID, DEFAULT_LOCALE_ID);
        setLocaleId(localeId || DEFAULT_LOCALE_ID);
        const enableRootComponentbootstrap = envInjector.get(ENABLE_ROOT_COMPONENT_BOOTSTRAP, true);
        if (!enableRootComponentbootstrap) {
          if (isApplicationBootstrapConfig(config)) {
            return envInjector.get(ApplicationRef);
          }
          config.allPlatformModules.push(config.moduleRef);
          return config.moduleRef;
        }
        if (typeof ngDevMode === 'undefined' || ngDevMode) {
          const imagePerformanceService = envInjector.get(ImagePerformanceWarning);
          imagePerformanceService.start();
        }
        if (isApplicationBootstrapConfig(config)) {
          const appRef = envInjector.get(ApplicationRef);
          if (config.rootComponent !== undefined) {
            appRef.bootstrap(config.rootComponent);
          }
          return appRef;
        } else {
          moduleBootstrapImpl?.(config.moduleRef, config.allPlatformModules);
          return config.moduleRef;
        }
      }).finally(() => void pendingTasks.remove(taskId));
    });
  });
}
let moduleBootstrapImpl;
function setModuleBootstrapImpl() {
  moduleBootstrapImpl = _moduleDoBootstrap;
}
function _moduleDoBootstrap(moduleRef, allPlatformModules) {
  const appRef = moduleRef.injector.get(ApplicationRef);
  if (moduleRef._bootstrapComponents.length > 0) {
    moduleRef._bootstrapComponents.forEach(f => appRef.bootstrap(f));
  } else if (moduleRef.instance.ngDoBootstrap) {
    moduleRef.instance.ngDoBootstrap(appRef);
  } else {
    throw new RuntimeError(-403, ngDevMode && `The module ${stringify(moduleRef.instance.constructor)} was bootstrapped, ` + `but it does not declare "@NgModule.bootstrap" components nor a "ngDoBootstrap" method. ` + `Please define one of these.`);
  }
  allPlatformModules.push(moduleRef);
}
function _callAndReportToErrorHandler(errorHandler, ngZone, callback) {
  try {
    const result = callback();
    if (isPromise(result)) {
      return result.catch(e => {
        ngZone.runOutsideAngular(() => errorHandler(e));
        throw e;
      });
    }
    return result;
  } catch (e) {
    ngZone.runOutsideAngular(() => errorHandler(e));
    throw e;
  }
}

class PlatformRef {
  _injector;
  _modules = [];
  _destroyListeners = [];
  _destroyed = false;
  constructor(_injector) {
    this._injector = _injector;
  }
  bootstrapModuleFactory(moduleFactory, options) {
    const allAppProviders = [provideZonelessChangeDetectionInternal(), ...(options?.applicationProviders ?? []), errorHandlerEnvironmentInitializer, ...(ngDevMode ? [validAppIdInitializer] : [])];
    const moduleRef = createNgModuleRefWithProviders(moduleFactory.moduleType, this.injector, allAppProviders);
    setModuleBootstrapImpl();
    return bootstrap({
      moduleRef,
      allPlatformModules: this._modules,
      platformInjector: this.injector
    });
  }
  bootstrapModule(moduleType, compilerOptions = []) {
    const options = optionsReducer({}, compilerOptions);
    setModuleBootstrapImpl();
    return compileNgModuleFactory(this.injector, options, moduleType).then(moduleFactory => this.bootstrapModuleFactory(moduleFactory, options));
  }
  onDestroy(callback) {
    this._destroyListeners.push(callback);
  }
  get injector() {
    return this._injector;
  }
  destroy() {
    if (this._destroyed) {
      throw new RuntimeError(404, ngDevMode && 'The platform has already been destroyed!');
    }
    this._modules.slice().forEach(module => module.destroy());
    this._destroyListeners.forEach(listener => listener());
    const destroyListeners = this._injector.get(PLATFORM_DESTROY_LISTENERS, null);
    if (destroyListeners) {
      destroyListeners.forEach(listener => listener());
      destroyListeners.clear();
    }
    this._destroyed = true;
  }
  get destroyed() {
    return this._destroyed;
  }
  static ɵfac = function PlatformRef_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || PlatformRef)(__inject(Injector));
  };
  static ɵprov = /*@__PURE__*/__defineInjectable({
    token: PlatformRef,
    factory: PlatformRef.ɵfac,
    providedIn: 'platform'
  });
}
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PlatformRef, [{
    type: Injectable,
    args: [{
      providedIn: 'platform'
    }]
  }], () => [{
    type: Injector
  }], null);
})();

function serializeInjector(injector) {
  const metadata = getInjectorMetadata(injector);
  if (metadata?.type === 'null') {
    return {
      name: 'Null Injector',
      type: 'null',
      providers: [],
      children: []
    };
  }
  let allProviders = [];
  if (metadata?.type === 'element' || metadata?.type === 'environment') {
    allProviders = getInjectorProviders(injector).map(record => {
      return {
        token: record.token,
        value: injector.get(record.token, null, {
          optional: true,
          self: true
        })
      };
    });
  }
  if (metadata?.type === 'element') {
    const tNode = getNodeInjectorTNode(injector);
    const viewProvidersCount = tNode ? tNode.providerIndexes >> 20 : 0;
    const viewProviders = allProviders.slice(0, viewProvidersCount);
    const resolvedProviders = allProviders.slice(viewProvidersCount);
    return {
      name: injector.constructor.name,
      type: 'element',
      providers: resolvedProviders,
      viewProviders,
      children: [],
      hostElement: metadata.source
    };
  }
  return {
    name: metadata?.source ?? injector.constructor.name ?? 'Unknown Injector',
    type: 'environment',
    providers: allProviders,
    children: []
  };
}

const diGraphTool = {
  name: 'angular:di_graph',
  description: `
Exposes the Angular Dependency Injection (DI) graph of the application.

This tool extracts both the element injector tree (associated with DOM elements and components)
and the environment injector tree (associated with modules and standalone application roots).
It captures the relationship structure and the providers resolved at each level.

Returns:
- \`elementInjectorRoots\`: An array of root element injectors (one for each Angular application
  root found). Each node forms a tree hierarchy:
  - \`name\`: The constructor name of this injector.
  - \`type\`: 'element'.
  - \`providers\`: Array of providers configured on this injector.
    - \`token\`: The DI token.
    - \`value\`: The resolved value of that provider if it was instantiated.
  - \`hostElement\`: The DOM element that this injector is associated with.
  - \`children\`: Array of child element injectors.
- \`environmentInjectorRoot\`: The root environment injector. It forms a tree hierarchy of nodes
  representing all environment injectors:
  - \`name\`: The identifier for the environment injector.
  - \`type\`: 'environment' or 'null'.
  - \`providers\`: Array of providers configured on this injector.
    - \`token\`: The DI token.
    - \`value\`: The resolved value of that provider if it was instantiated.
  - \`children\`: Array of child environment injectors.
  `.trim(),
  inputSchema: {
    type: 'object',
    properties: {}
  },
  execute: async () => {
    const roots = Array.from(document.querySelectorAll('[ng-version]'));
    if (roots.length === 0) {
      throw new Error('Could not find Angular root element ([ng-version]) on the page.');
    }
    return discoverDiGraph(roots);
  }
};
function discoverDiGraph(roots) {
  const rootLViews = roots.map(root => {
    const lContext = getLContext(root);
    if (!lContext?.lView) {
      throw new Error(`Could not find an \`LView\` for root \`<${root.tagName.toLowerCase()}>\`, is it an Angular component?`);
    }
    return lContext.lView;
  });
  return {
    elementInjectorRoots: rootLViews.map(rootLView => walkElementInjectors(rootLView)),
    environmentInjectorRoot: collectEnvInjectors(rootLViews)
  };
}
function walkElementInjectors(rootLView) {
  if (rootLView[TVIEW].type !== 0) {
    throw new Error(`Expected a root LView but got type: \`${rootLView[TVIEW].type}\`.`);
  }
  const stack = [];
  for (const [tNode, lView] of walkLViewDirectives(rootLView)) {
    const injector = new NodeInjector(tNode, lView);
    const serialized = serializeInjector(injector);
    while (stack.length > 0) {
      const [lastTNode, lastLView, lastInjector] = stack[stack.length - 1];
      const isDescendantInSameView = isTNodeDescendant(tNode, lastTNode);
      const isDescendantInDifferentView = isLViewDescendantOfTNode(lView, lastLView, lastTNode);
      if (isDescendantInSameView || isDescendantInDifferentView) {
        lastInjector.children.push(serialized);
        break;
      } else {
        stack.pop();
      }
    }
    stack.push([tNode, lView, serialized]);
  }
  if (stack.length === 0) {
    throw new Error(`Expected at least one component/directive in the root \`LView\`.`);
  }
  const [,, rootInjector] = stack[0];
  return rootInjector;
}
function collectEnvInjectors(rootLViews) {
  const serializedEnvInjectorMap = new Map();
  let rootEnvInjector = undefined;
  function serializeAncestors(injector) {
    const existing = serializedEnvInjectorMap.get(injector);
    if (existing) return existing;
    const serialized = serializeInjector(injector);
    serializedEnvInjectorMap.set(injector, serialized);
    const parentInjector = getParentEnvInjector(injector);
    if (parentInjector) {
      const parentSerialized = serializeAncestors(parentInjector);
      parentSerialized.children.push(serialized);
    } else {
      if (!rootEnvInjector) {
        rootEnvInjector = serialized;
      } else if (rootEnvInjector !== serialized) {
        throw new Error('Expected only one root environment injector, but found multiple.', {
          cause: {
            firstRoot: rootEnvInjector,
            secondRoot: serialized
          }
        });
      }
    }
    return serialized;
  }
  for (const rootLView of rootLViews) {
    for (const [, lView] of walkLViewDirectives(rootLView)) {
      serializeAncestors(lView[INJECTOR]);
    }
  }
  if (!rootEnvInjector) {
    throw new Error('Expected a root environment injector but did not find one.');
  }
  return rootEnvInjector;
}
function isTNodeDescendant(node, ancestor) {
  let curr = node;
  while (curr) {
    if (curr === ancestor) return true;
    curr = curr.parent;
  }
  return false;
}
function isLViewDescendantOfTNode(lView, parentLView, parentTNode) {
  let currentLView = lView;
  let hostTNode = null;
  while (currentLView && currentLView !== parentLView) {
    hostTNode = currentLView[T_HOST];
    currentLView = getLViewParent(currentLView);
  }
  return currentLView === parentLView && hostTNode !== null && isTNodeDescendant(hostTNode, parentTNode);
}
function getParentEnvInjector(injector) {
  if (injector instanceof ChainedInjector) {
    const chainedInjector = injector;
    return chainedInjector.parentInjector;
  } else if (injector instanceof R3Injector) {
    return injector.parent;
  } else if (injector instanceof NullInjector) {
    return undefined;
  } else {
    throw new Error(`Unknown injector type: "${injector.constructor.name}".`);
  }
}

const signalGraphTool = {
  name: 'angular:signal_graph',
  description: `
Exposes the Angular signal dependency graph for a given DOM element.

This tool extracts the reactive dependency graph (signals, computeds, and effects) that
are transitive dependencies of the effects of that element. It will include signals
authored in other components/services and depended upon by the target component, but
will *not* include signals only used in descendant components effects.

Params:
- \`target\`: The element to get the signal graph for. Must be the host element of an
  Angular component.

Returns:
- \`nodes\`: An array of reactive nodes discovered in the context. Each node contains:
  - \`kind\`: The type of reactive node ('signal', 'computed', 'effect', or 'template'
    for component template effects).
  - \`value\`: The current evaluated value of the node (if applicable).
  - \`label\`: The symbol name of the associated signal if available (ex.
    \`const foo = signal(0);\` has \`label: 'foo'\`).
  - \`epoch\`: The internal version number of the node's value.
- \`edges\`: An array of dependency links representing which nodes read from which other
  nodes.
  - \`consumer\`: The index in the \`nodes\` array of the node that depends on the value.
  - \`producer\`: The index in the \`nodes\` array of the node that provides the value.

Example: An edge with \`{consumer: 2, producer: 0}\` means that \`nodes[2]\` (e.g. an
\`effect\`) reads the value of \`nodes[0]\` (e.g. a \`signal\`).
  `.trim(),
  inputSchema: {
    type: 'object',
    properties: {
      target: {
        type: 'object',
        description: 'The element to get the signal graph for.',
        'x-mcp-type': 'HTMLElement'
      }
    },
    required: ['target']
  },
  execute: async ({
    target
  }) => {
    if (!(target instanceof HTMLElement)) {
      throw new Error('Invalid input: "target" must be an HTMLElement.');
    }
    const injector = getInjector(target);
    if (injector instanceof NullInjector) {
      throw new Error('Invalid input: "target" is not the host element of an Angular component.');
    }
    const graph = getSignalGraph(injector);
    return {
      nodes: graph.nodes.map(({
        id,
        debuggableFn,
        ...node
      }) => node),
      edges: graph.edges
    };
  }
};

function registerAiTools() {
  if (typeof window === 'undefined' || !window.addEventListener) return () => {};
  function listener(inputEvent) {
    const event = inputEvent;
    event.respondWith({
      name: 'Angular',
      tools: [diGraphTool, signalGraphTool]
    });
  }
  window.addEventListener('devtoolstooldiscovery', listener);
  return () => {
    window.removeEventListener('devtoolstooldiscovery', listener);
  };
}

let _platformInjector = null;
let _unregisterAiTools = null;
function createPlatform(injector) {
  if (getPlatform()) {
    throw new RuntimeError(400, ngDevMode && 'There can be only one platform. Destroy the previous one to create a new one.');
  }
  publishDefaultGlobalUtils();
  publishSignalConfiguration();
  if (typeof ngDevMode !== 'undefined' && ngDevMode) {
    _unregisterAiTools = registerAiTools();
  }
  _platformInjector = typeof ngServerMode === 'undefined' || !ngServerMode ? injector : null;
  const platform = injector.get(PlatformRef);
  runPlatformInitializers(injector);
  return platform;
}
function createPlatformFactory(parentPlatformFactory, name, providers = []) {
  const desc = `Platform: ${name}`;
  const marker = new InjectionToken(desc);
  return (extraProviders = []) => {
    let platform = getPlatform();
    if (!platform) {
      const platformProviders = [...providers, ...extraProviders, {
        provide: marker,
        useValue: true
      }];
      platform = parentPlatformFactory?.(platformProviders) ?? createPlatform(createPlatformInjector(platformProviders, desc));
    }
    return typeof ngServerMode !== 'undefined' && ngServerMode ? platform : assertPlatform(marker);
  };
}
function createPlatformInjector(providers = [], name) {
  return Injector.create({
    name,
    providers: [{
      provide: INJECTOR_SCOPE,
      useValue: 'platform'
    }, {
      provide: PLATFORM_DESTROY_LISTENERS,
      useValue: new Set([() => _platformInjector = null])
    }, ...providers]
  });
}
function assertPlatform(requiredToken) {
  const platform = getPlatform();
  if (!platform) {
    throw new RuntimeError(-401, ngDevMode && 'No platform exists!');
  }
  if ((typeof ngDevMode === 'undefined' || ngDevMode) && !platform.injector.get(requiredToken, null)) {
    throw new RuntimeError(400, 'A platform with a different configuration has been created. Please destroy it first.');
  }
  return platform;
}
function getPlatform() {
  if (typeof ngServerMode !== 'undefined' && ngServerMode) {
    return null;
  }
  return _platformInjector?.get(PlatformRef) ?? null;
}
function destroyPlatform() {
  if (typeof ngDevMode !== 'undefined' && ngDevMode) {
    _unregisterAiTools?.();
    _unregisterAiTools = null;
  }
  getPlatform()?.destroy();
}
function createOrReusePlatformInjector(providers = []) {
  if (_platformInjector) return _platformInjector;
  publishDefaultGlobalUtils();
  if (typeof ngDevMode !== 'undefined' && ngDevMode) {
    _unregisterAiTools = registerAiTools();
  }
  const injector = createPlatformInjector(providers);
  if (typeof ngServerMode === 'undefined' || !ngServerMode) {
    _platformInjector = injector;
  }
  publishSignalConfiguration();
  runPlatformInitializers(injector);
  return injector;
}
function providePlatformInitializer(initializerFn) {
  return {
    provide: PLATFORM_INITIALIZER,
    useValue: initializerFn,
    multi: true
  };
}
function runPlatformInitializers(injector) {
  const inits = injector.get(PLATFORM_INITIALIZER, null);
  runInInjectionContext(injector, () => {
    inits?.forEach(init => init());
  });
}

function internalCreateApplication(config) {
  const {
    rootComponent,
    appProviders,
    platformProviders,
    platformRef
  } = config;
  profiler(ProfilerEvent.BootstrapApplicationStart);
  if (typeof ngServerMode !== 'undefined' && ngServerMode && !platformRef) {
    throw new RuntimeError(-401, ngDevMode && 'Missing Platform: This may be due to using `bootstrapApplication` on the server without passing a `BootstrapContext`. ' + 'Please make sure that `bootstrapApplication` is called with a `context` argument.');
  }
  try {
    const platformInjector = platformRef?.injector ?? createOrReusePlatformInjector(platformProviders);
    if ((typeof ngDevMode === 'undefined' || ngDevMode) && rootComponent !== undefined) {
      assertStandaloneComponentType(rootComponent);
    }
    const allAppProviders = [provideZonelessChangeDetectionInternal(), errorHandlerEnvironmentInitializer, ...(ngDevMode ? [validAppIdInitializer] : []), ...(appProviders || [])];
    const adapter = new EnvironmentNgModuleRefAdapter({
      providers: allAppProviders,
      parent: platformInjector,
      debugName: typeof ngDevMode === 'undefined' || ngDevMode ? 'Environment Injector' : '',
      runEnvironmentInitializers: false
    });
    return bootstrap({
      r3Injector: adapter.injector,
      platformInjector,
      rootComponent
    });
  } catch (e) {
    return Promise.reject(e);
  } finally {
    profiler(ProfilerEvent.BootstrapApplicationEnd);
  }
}

class SerializedViewCollection {
  views = [];
  indexByContent = new Map();
  add(serializedView) {
    const viewAsString = JSON.stringify(serializedView);
    if (!this.indexByContent.has(viewAsString)) {
      const index = this.views.length;
      this.views.push(serializedView);
      this.indexByContent.set(viewAsString, index);
      return index;
    }
    return this.indexByContent.get(viewAsString);
  }
  getAll() {
    return this.views;
  }
}
let tViewSsrId = 0;
function getSsrId(tView) {
  if (!tView.ssrId) {
    tView.ssrId = `t${tViewSsrId++}`;
  }
  return tView.ssrId;
}
function calcNumRootNodes(tView, lView, tNode) {
  const rootNodes = [];
  collectNativeNodes(tView, lView, tNode, rootNodes);
  return rootNodes.length;
}
function calcNumRootNodesInLContainer(lContainer) {
  const rootNodes = [];
  collectNativeNodesInLContainer(lContainer, rootNodes);
  return rootNodes.length;
}
function annotateComponentLViewForHydration(lView, context) {
  const hostElement = lView[HOST];
  if (hostElement && !hostElement.hasAttribute(SKIP_HYDRATION_ATTR_NAME)) {
    return annotateHostElementForHydration(hostElement, lView, null, context);
  }
  return null;
}
function annotateLContainerForHydration(lContainer, context) {
  const componentLView = unwrapLView(lContainer[HOST]);
  const componentLViewNghIndex = annotateComponentLViewForHydration(componentLView, context);
  if (componentLViewNghIndex === null) {
    return;
  }
  const hostElement = unwrapRNode(componentLView[HOST]);
  const rootLView = lContainer[PARENT];
  const rootLViewNghIndex = annotateHostElementForHydration(hostElement, rootLView, null, context);
  const renderer = componentLView[RENDERER];
  const finalIndex = `${componentLViewNghIndex}|${rootLViewNghIndex}`;
  renderer.setAttribute(hostElement, NGH_ATTR_NAME, finalIndex);
}
function annotateForHydration(appRef, doc) {
  const injector = appRef.injector;
  const isI18nHydrationEnabledVal = isI18nHydrationEnabled(injector);
  const isIncrementalHydrationEnabledVal = isIncrementalHydrationEnabled(injector);
  const serializedViewCollection = new SerializedViewCollection();
  const corruptedTextNodes = new Map();
  const viewRefs = appRef._views;
  const shouldReplayEvents = injector.get(IS_EVENT_REPLAY_ENABLED, EVENT_REPLAY_ENABLED_DEFAULT);
  const eventTypesToReplay = {
    regular: new Set(),
    capture: new Set()
  };
  const deferBlocks = new Map();
  appRef.injector.get(APP_ID);
  for (const viewRef of viewRefs) {
    const lNode = getLNodeForHydration(viewRef);
    if (lNode !== null) {
      const context = {
        serializedViewCollection,
        corruptedTextNodes,
        isI18nHydrationEnabled: isI18nHydrationEnabledVal,
        isIncrementalHydrationEnabled: isIncrementalHydrationEnabledVal,
        i18nChildren: new Map(),
        eventTypesToReplay,
        shouldReplayEvents,
        deferBlocks
      };
      if (isLContainer(lNode)) {
        annotateLContainerForHydration(lNode, context);
      } else {
        annotateComponentLViewForHydration(lNode, context);
      }
      insertCorruptedTextNodeMarkers(corruptedTextNodes, doc);
    }
  }
  const serializedViews = serializedViewCollection.getAll();
  const transferState = injector.get(TransferState);
  transferState.set(NGH_DATA_KEY, serializedViews);
  if (deferBlocks.size > 0) {
    const blocks = {};
    for (const [id, info] of deferBlocks.entries()) {
      blocks[id] = info;
    }
    transferState.set(NGH_DEFER_BLOCKS_KEY, blocks);
  }
  return eventTypesToReplay;
}
function serializeLContainer(lContainer, tNode, lView, parentDeferBlockId, context) {
  const views = [];
  let lastViewAsString = '';
  for (let i = CONTAINER_HEADER_OFFSET; i < lContainer.length; i++) {
    let childLView = lContainer[i];
    let template;
    let numRootNodes;
    let serializedView;
    if (isRootView(childLView)) {
      childLView = childLView[HEADER_OFFSET];
      if (isLContainer(childLView)) {
        numRootNodes = calcNumRootNodesInLContainer(childLView) + 2;
        annotateLContainerForHydration(childLView, context);
        const componentLView = unwrapLView(childLView[HOST]);
        serializedView = {
          [TEMPLATE_ID]: componentLView[TVIEW].ssrId,
          [NUM_ROOT_NODES]: numRootNodes
        };
      }
    }
    if (!serializedView) {
      const childTView = childLView[TVIEW];
      if (childTView.type === 1) {
        template = childTView.ssrId;
        numRootNodes = 1;
      } else {
        template = getSsrId(childTView);
        numRootNodes = calcNumRootNodes(childTView, childLView, childTView.firstChild);
      }
      serializedView = {
        [TEMPLATE_ID]: template,
        [NUM_ROOT_NODES]: numRootNodes
      };
      let isHydrateNeverBlock = false;
      if (isDeferBlock(lView[TVIEW], tNode)) {
        const lDetails = getLDeferBlockDetails(lView, tNode);
        const tDetails = getTDeferBlockDetails(lView[TVIEW], tNode);
        if (context.isIncrementalHydrationEnabled && tDetails.hydrateTriggers !== null) {
          const deferBlockId = `d${context.deferBlocks.size}`;
          if (tDetails.hydrateTriggers.has(7)) {
            isHydrateNeverBlock = true;
          }
          let rootNodes = [];
          collectNativeNodesInLContainer(lContainer, rootNodes);
          const deferBlockInfo = {
            [NUM_ROOT_NODES]: rootNodes.length,
            [DEFER_BLOCK_STATE]: lDetails[DEFER_BLOCK_STATE$1]
          };
          const serializedTriggers = serializeHydrateTriggers(tDetails.hydrateTriggers);
          if (serializedTriggers.length > 0) {
            deferBlockInfo[DEFER_HYDRATE_TRIGGERS] = serializedTriggers;
          }
          if (parentDeferBlockId !== null) {
            deferBlockInfo[DEFER_PARENT_BLOCK_ID] = parentDeferBlockId;
          }
          context.deferBlocks.set(deferBlockId, deferBlockInfo);
          const node = unwrapRNode(lContainer);
          if (node !== undefined) {
            if (node.nodeType === Node.COMMENT_NODE) {
              annotateDeferBlockAnchorForHydration(node, deferBlockId);
            }
          } else {
            ngDevMode && validateNodeExists(node, childLView, tNode);
            ngDevMode && validateMatchingNode(node, Node.COMMENT_NODE, null, childLView, tNode, true);
            annotateDeferBlockAnchorForHydration(node, deferBlockId);
          }
          if (!isHydrateNeverBlock) {
            annotateDeferBlockRootNodesWithJsAction(tDetails, rootNodes, deferBlockId, context);
          }
          parentDeferBlockId = deferBlockId;
          serializedView[DEFER_BLOCK_ID] = deferBlockId;
        }
        serializedView[DEFER_BLOCK_STATE] = lDetails[DEFER_BLOCK_STATE$1];
      }
      if (!isHydrateNeverBlock) {
        const childHostElement = unwrapRNode(childLView[HOST]);
        if (childLView[TVIEW].type !== 1 || childHostElement === null || !childHostElement.hasAttribute(SKIP_HYDRATION_ATTR_NAME)) {
          Object.assign(serializedView, serializeLView(lContainer[i], parentDeferBlockId, context));
        }
      }
    }
    const currentViewAsString = JSON.stringify(serializedView);
    if (views.length > 0 && currentViewAsString === lastViewAsString) {
      const previousView = views[views.length - 1];
      previousView[MULTIPLIER] ??= 1;
      previousView[MULTIPLIER]++;
    } else {
      lastViewAsString = currentViewAsString;
      views.push(serializedView);
    }
  }
  return views;
}
function serializeHydrateTriggers(triggerMap) {
  const serializableDeferBlockTrigger = new Set([0, 1, 2, 5]);
  let triggers = [];
  for (let [trigger, details] of triggerMap) {
    if (serializableDeferBlockTrigger.has(trigger)) {
      if (details === null) {
        triggers.push(trigger);
      } else if (details.type === 5) {
        triggers.push({
          trigger,
          delay: details.delay
        });
      } else {
        triggers.push({
          trigger,
          intersectionObserverOptions: details.intersectionObserverOptions
        });
      }
    }
  }
  return triggers;
}
function appendSerializedNodePath(ngh, tNode, lView, excludedParentNodes) {
  const noOffsetIndex = tNode.index - HEADER_OFFSET;
  ngh[NODES] ??= {};
  ngh[NODES][noOffsetIndex] ??= calcPathForNode(tNode, lView, excludedParentNodes);
}
function appendDisconnectedNodeIndex(ngh, tNodeOrNoOffsetIndex) {
  const noOffsetIndex = typeof tNodeOrNoOffsetIndex === 'number' ? tNodeOrNoOffsetIndex : tNodeOrNoOffsetIndex.index - HEADER_OFFSET;
  ngh[DISCONNECTED_NODES] ??= [];
  if (!ngh[DISCONNECTED_NODES].includes(noOffsetIndex)) {
    ngh[DISCONNECTED_NODES].push(noOffsetIndex);
  }
}
function serializeLView(lView, parentDeferBlockId = null, context) {
  const ngh = {};
  const tView = lView[TVIEW];
  const i18nChildren = getOrComputeI18nChildren(tView, context);
  const nativeElementsToEventTypes = context.shouldReplayEvents ? collectDomEventsInfo(tView, lView, context.eventTypesToReplay) : null;
  for (let i = HEADER_OFFSET; i < tView.bindingStartIndex; i++) {
    const tNode = tView.data[i];
    const noOffsetIndex = i - HEADER_OFFSET;
    const i18nData = trySerializeI18nBlock(lView, i, context);
    if (i18nData) {
      ngh[I18N_DATA] ??= {};
      ngh[I18N_DATA][noOffsetIndex] = i18nData.caseQueue;
      for (const nodeNoOffsetIndex of i18nData.disconnectedNodes) {
        appendDisconnectedNodeIndex(ngh, nodeNoOffsetIndex);
      }
      for (const nodeNoOffsetIndex of i18nData.disjointNodes) {
        const tNode = tView.data[nodeNoOffsetIndex + HEADER_OFFSET];
        ngDevMode && assertTNode(tNode);
        appendSerializedNodePath(ngh, tNode, lView, i18nChildren);
      }
      continue;
    }
    if (!isTNodeShape(tNode)) {
      continue;
    }
    if (isDetachedByI18n(tNode)) {
      continue;
    }
    if (isLContainer(lView[i]) && tNode.tView) {
      ngh[TEMPLATES] ??= {};
      ngh[TEMPLATES][noOffsetIndex] = getSsrId(tNode.tView);
    }
    if (isDisconnectedNode(tNode, lView) && isContentProjectedNode(tNode)) {
      appendDisconnectedNodeIndex(ngh, tNode);
      continue;
    }
    if (Array.isArray(tNode.projection)) {
      for (const projectionHeadTNode of tNode.projection) {
        if (!projectionHeadTNode) continue;
        if (!Array.isArray(projectionHeadTNode)) {
          if (!isProjectionTNode(projectionHeadTNode) && !isInSkipHydrationBlock(projectionHeadTNode)) {
            if (isDisconnectedNode(projectionHeadTNode, lView)) {
              appendDisconnectedNodeIndex(ngh, projectionHeadTNode);
            } else {
              appendSerializedNodePath(ngh, projectionHeadTNode, lView, i18nChildren);
            }
          }
        } else {
          throw unsupportedProjectionOfDomNodes(unwrapRNode(lView[i]));
        }
      }
    }
    conditionallyAnnotateNodePath(ngh, tNode, lView, i18nChildren);
    if (isLContainer(lView[i])) {
      const hostNode = lView[i][HOST];
      if (Array.isArray(hostNode)) {
        const targetNode = unwrapRNode(hostNode);
        if (!targetNode.hasAttribute(SKIP_HYDRATION_ATTR_NAME)) {
          annotateHostElementForHydration(targetNode, hostNode, parentDeferBlockId, context);
        }
      }
      ngh[CONTAINERS] ??= {};
      ngh[CONTAINERS][noOffsetIndex] = serializeLContainer(lView[i], tNode, lView, parentDeferBlockId, context);
    } else if (Array.isArray(lView[i]) && !isLetDeclaration(tNode)) {
      const targetNode = unwrapRNode(lView[i][HOST]);
      if (!targetNode.hasAttribute(SKIP_HYDRATION_ATTR_NAME)) {
        annotateHostElementForHydration(targetNode, lView[i], parentDeferBlockId, context);
      }
    } else {
      if (tNode.type & 8) {
        ngh[ELEMENT_CONTAINERS] ??= {};
        ngh[ELEMENT_CONTAINERS][noOffsetIndex] = calcNumRootNodes(tView, lView, tNode.child);
      } else if (tNode.type & (16 | 128)) {
        let nextTNode = tNode.next;
        while (nextTNode !== null && nextTNode.type & (16 | 128)) {
          nextTNode = nextTNode.next;
        }
        if (nextTNode && !isInSkipHydrationBlock(nextTNode)) {
          appendSerializedNodePath(ngh, nextTNode, lView, i18nChildren);
        }
      } else if (tNode.type & 1) {
        const rNode = unwrapRNode(lView[i]);
        processTextNodeBeforeSerialization(context, rNode);
      }
    }
    if (nativeElementsToEventTypes && tNode.type & 2) {
      const nativeElement = unwrapRNode(lView[i]);
      if (nativeElementsToEventTypes.has(nativeElement)) {
        setJSActionAttributes(nativeElement, nativeElementsToEventTypes.get(nativeElement), parentDeferBlockId);
      }
    }
  }
  return ngh;
}
function conditionallyAnnotateNodePath(ngh, tNode, lView, excludedParentNodes) {
  if (isProjectionTNode(tNode)) {
    return;
  }
  if (tNode.projectionNext && tNode.projectionNext !== tNode.next && !isInSkipHydrationBlock(tNode.projectionNext)) {
    appendSerializedNodePath(ngh, tNode.projectionNext, lView, excludedParentNodes);
  }
  if (tNode.prev === null && tNode.parent !== null && isDisconnectedNode(tNode.parent, lView) && !isDisconnectedNode(tNode, lView)) {
    appendSerializedNodePath(ngh, tNode, lView, excludedParentNodes);
  }
}
function componentUsesShadowDomEncapsulation(lView) {
  const instance = lView[CONTEXT];
  if (!instance?.constructor) return false;
  const def = getComponentDef(instance.constructor);
  return def?.encapsulation === ViewEncapsulation$1.ShadowDom || def?.encapsulation === ViewEncapsulation$1.ExperimentalIsolatedShadowDom;
}
function annotateHostElementForHydration(element, lView, parentDeferBlockId, context) {
  const renderer = lView[RENDERER];
  if (hasI18n(lView) && !isI18nHydrationSupportEnabled() || componentUsesShadowDomEncapsulation(lView)) {
    renderer.setAttribute(element, SKIP_HYDRATION_ATTR_NAME, '');
    return null;
  } else {
    const ngh = serializeLView(lView, parentDeferBlockId, context);
    const index = context.serializedViewCollection.add(ngh);
    renderer.setAttribute(element, NGH_ATTR_NAME, index.toString());
    return index;
  }
}
function annotateDeferBlockAnchorForHydration(comment, deferBlockId) {
  comment.textContent = `ngh=${deferBlockId}`;
}
function insertCorruptedTextNodeMarkers(corruptedTextNodes, doc) {
  for (const [textNode, marker] of corruptedTextNodes) {
    textNode.after(doc.createComment(marker));
  }
}
function isContentProjectedNode(tNode) {
  let currentTNode = tNode;
  while (currentTNode != null) {
    if (isComponentHost(currentTNode)) {
      return true;
    }
    currentTNode = currentTNode.parent;
  }
  return false;
}
function annotateDeferBlockRootNodesWithJsAction(tDetails, rootNodes, parentDeferBlockId, context) {
  const actionList = convertHydrateTriggersToJsAction(tDetails.hydrateTriggers);
  for (let et of actionList) {
    context.eventTypesToReplay.regular.add(et);
  }
  if (actionList.length > 0) {
    const elementNodes = rootNodes.filter(rn => rn.nodeType === Node.ELEMENT_NODE);
    for (let rNode of elementNodes) {
      setJSActionAttributes(rNode, actionList, parentDeferBlockId);
    }
  }
}

function getCurrentClosestComponentInstance(predicate) {
  let lView = getLView();
  while (lView) {
    if (lView[TVIEW].type === 1 && predicate(lView[CONTEXT])) {
      return lView[CONTEXT];
    }
    if (isRootView(lView)) {
      break;
    } else {
      lView = getLViewParent(lView);
    }
  }
  return null;
}

const PERFORMANCE_MARK_PREFIX = '🅰️';
let enablePerfLogging = false;
function startMeasuring(label) {
  if (!enablePerfLogging) {
    return;
  }
  const {
    startLabel
  } = labels(label);
  performance.mark(startLabel);
}
function stopMeasuring(label) {
  if (!enablePerfLogging) {
    return;
  }
  const {
    startLabel,
    labelName,
    endLabel
  } = labels(label);
  performance.mark(endLabel);
  performance.measure(labelName, startLabel, endLabel);
  performance.clearMarks(startLabel);
  performance.clearMarks(endLabel);
}
function labels(label) {
  const labelName = `${PERFORMANCE_MARK_PREFIX}:${label}`;
  return {
    labelName,
    startLabel: `start:${labelName}`,
    endLabel: `end:${labelName}`
  };
}
let warningLogged = false;
function enableProfiling() {
  if (!warningLogged && (typeof performance === 'undefined' || !performance.mark || !performance.measure)) {
    warningLogged = true;
    console.warn('Performance API is not supported on this platform');
    return;
  }
  enablePerfLogging = true;
}
function disableProfiling() {
  enablePerfLogging = false;
}

function ɵassertType(value) {}

function booleanAttribute(value) {
  return typeof value === 'boolean' ? value : value != null && value !== 'false';
}
function numberAttribute(value, fallbackValue = NaN) {
  const isNumberValue = !isNaN(parseFloat(value)) && !isNaN(Number(value));
  return isNumberValue ? Number(value) : fallbackValue;
}

const NOT_SET = /* @__PURE__ */Symbol('NOT_SET');
const EMPTY_CLEANUP_SET = /* @__PURE__ */new Set();
const AFTER_RENDER_PHASE_EFFECT_NODE = /* @__PURE__ */(() => ({
  ...SIGNAL_NODE,
  kind: 'afterRenderEffectPhase',
  consumerIsAlwaysLive: true,
  consumerAllowSignalWrites: true,
  value: NOT_SET,
  cleanup: null,
  consumerMarkedDirty() {
    if (this.sequence.impl.executing) {
      if (this.sequence.lastPhase === null || this.sequence.lastPhase < this.phase) {
        return;
      }
      this.sequence.erroredOrDestroyed = true;
    }
    this.sequence.scheduler.notify(7);
  },
  phaseFn(previousValue) {
    this.sequence.lastPhase = this.phase;
    if (!this.dirty) {
      return this.signal;
    }
    this.dirty = false;
    if (this.value !== NOT_SET && !consumerPollProducersForChange(this)) {
      return this.signal;
    }
    try {
      for (const cleanupFn of this.cleanup ?? EMPTY_CLEANUP_SET) {
        cleanupFn();
      }
    } finally {
      this.cleanup?.clear();
    }
    const args = [];
    if (previousValue !== undefined) {
      args.push(previousValue);
    }
    args.push(this.registerCleanupFn);
    const prevConsumer = consumerBeforeComputation(this);
    let newValue;
    try {
      newValue = this.userFn.apply(null, args);
    } finally {
      consumerAfterComputation(this, prevConsumer);
    }
    if (this.value === NOT_SET || !this.equal(this.value, newValue)) {
      this.value = newValue;
      this.version++;
    }
    return this.signal;
  }
}))();
class AfterRenderEffectSequence extends AfterRenderSequence {
  scheduler;
  lastPhase = null;
  nodes = [undefined, undefined, undefined, undefined];
  onDestroyFns = null;
  constructor(impl, effectHooks, view, scheduler, injector, snapshot = null) {
    super(impl, [undefined, undefined, undefined, undefined], view, false, injector.get(DestroyRef), snapshot);
    this.scheduler = scheduler;
    for (const phase of AFTER_RENDER_PHASES) {
      const effectHook = effectHooks[phase];
      if (effectHook === undefined) {
        continue;
      }
      const node = Object.create(AFTER_RENDER_PHASE_EFFECT_NODE);
      node.sequence = this;
      node.phase = phase;
      node.userFn = effectHook;
      node.dirty = true;
      node.signal = () => {
        producerAccessed(node);
        return node.value;
      };
      node.signal[SIGNAL] = node;
      node.registerCleanupFn = fn => (node.cleanup ??= new Set()).add(fn);
      this.nodes[phase] = node;
      this.hooks[phase] = value => node.phaseFn(value);
      if (ngDevMode) {
        setupDebugInfo(node, injector);
      }
    }
  }
  afterRun() {
    super.afterRun();
    this.lastPhase = null;
  }
  destroy() {
    if (this.onDestroyFns !== null) {
      for (const fn of this.onDestroyFns) {
        fn();
      }
    }
    super.destroy();
    for (const node of this.nodes) {
      if (node) {
        try {
          for (const fn of node.cleanup ?? EMPTY_CLEANUP_SET) {
            fn();
          }
        } finally {
          consumerDestroy(node);
        }
      }
    }
  }
}
function afterRenderEffect(callbackOrSpec, options) {
  ngDevMode && assertNotInReactiveContext(afterRenderEffect, 'Call `afterRenderEffect` outside of a reactive context. For example, create the render ' + 'effect inside the component constructor`.');
  if (ngDevMode && !options?.injector) {
    assertInInjectionContext(afterRenderEffect);
  }
  if (typeof ngServerMode !== 'undefined' && ngServerMode) {
    return NOOP_AFTER_RENDER_REF;
  }
  const injector = options?.injector ?? inject(Injector);
  const scheduler = injector.get(ChangeDetectionScheduler);
  const manager = injector.get(AfterRenderManager);
  const tracing = injector.get(TracingService, null, {
    optional: true
  });
  manager.impl ??= injector.get(AfterRenderImpl);
  let spec = callbackOrSpec;
  if (typeof spec === 'function') {
    spec = {
      mixedReadWrite: callbackOrSpec
    };
  }
  const viewContext = injector.get(ViewContext, null, {
    optional: true
  });
  const sequence = new AfterRenderEffectSequence(manager.impl, [spec.earlyRead, spec.write, spec.mixedReadWrite, spec.read], viewContext?.view, scheduler, injector, tracing?.snapshot(null));
  manager.impl.register(sequence);
  return sequence;
}
function setupDebugInfo(node, injector) {
  node.debugName = `afterRenderEffect - ${phaseDebugName(node.phase)} phase`;
  const prevInjectorProfilerContext = setInjectorProfilerContext({
    injector,
    token: null
  });
  try {
    emitAfterRenderEffectPhaseCreatedEvent(node);
  } finally {
    setInjectorProfilerContext(prevInjectorProfilerContext);
  }
}
function phaseDebugName(phase) {
  switch (phase) {
    case 0:
      return 'EarlyRead';
    case 1:
      return 'Write';
    case 2:
      return 'MixedReadWrite';
    case 3:
      return 'Read';
  }
}

function ɵɵngDeclareDirective(decl) {
  const compiler = getCompilerFacade({
    usage: 1,
    kind: 'directive',
    type: decl.type
  });
  return compiler.compileDirectiveDeclaration(angularCoreEnv, `ng:///${decl.type.name}/ɵfac.js`, decl);
}
function ɵɵngDeclareClassMetadata(decl) {
  setClassMetadata(decl.type, decl.decorators, decl.ctorParameters ?? null, decl.propDecorators ?? null);
}
function ɵɵngDeclareClassMetadataAsync(decl) {
  setClassMetadataAsync(decl.type, decl.resolveDeferredDeps, (...types) => {
    const meta = decl.resolveMetadata(...types);
    setClassMetadata(decl.type, meta.decorators, meta.ctorParameters, meta.propDecorators);
  });
}
function ɵɵngDeclareComponent(decl) {
  const compiler = getCompilerFacade({
    usage: 1,
    kind: 'component',
    type: decl.type
  });
  return compiler.compileComponentDeclaration(angularCoreEnv, `ng:///${decl.type.name}/ɵcmp.js`, decl);
}
function ɵɵngDeclareFactory(decl) {
  const compiler = getCompilerFacade({
    usage: 1,
    kind: getFactoryKind(decl.target),
    type: decl.type
  });
  return compiler.compileFactoryDeclaration(angularCoreEnv, `ng:///${decl.type.name}/ɵfac.js`, decl);
}
function getFactoryKind(target) {
  switch (target) {
    case FactoryTarget.Directive:
      return 'directive';
    case FactoryTarget.Component:
      return 'component';
    case FactoryTarget.Injectable:
      return 'injectable';
    case FactoryTarget.Pipe:
      return 'pipe';
    case FactoryTarget.NgModule:
      return 'NgModule';
    case FactoryTarget.Service:
      return 'service';
  }
}
function ɵɵngDeclareInjectable(decl) {
  const compiler = getCompilerFacade({
    usage: 1,
    kind: 'injectable',
    type: decl.type
  });
  return compiler.compileInjectableDeclaration(angularCoreEnv, `ng:///${decl.type.name}/ɵprov.js`, decl);
}
function ɵɵngDeclareInjector(decl) {
  const compiler = getCompilerFacade({
    usage: 1,
    kind: 'NgModule',
    type: decl.type
  });
  return compiler.compileInjectorDeclaration(angularCoreEnv, `ng:///${decl.type.name}/ɵinj.js`, decl);
}
function ɵɵngDeclareNgModule(decl) {
  const compiler = getCompilerFacade({
    usage: 1,
    kind: 'NgModule',
    type: decl.type
  });
  return compiler.compileNgModuleDeclaration(angularCoreEnv, `ng:///${decl.type.name}/ɵmod.js`, decl);
}
function ɵɵngDeclarePipe(decl) {
  const compiler = getCompilerFacade({
    usage: 1,
    kind: 'pipe',
    type: decl.type
  });
  return compiler.compilePipeDeclaration(angularCoreEnv, `ng:///${decl.type.name}/ɵpipe.js`, decl);
}
function ɵɵngDeclareService(decl) {
  const compiler = getCompilerFacade({
    usage: 1,
    kind: 'service',
    type: decl.type
  });
  return compiler.compileServiceDeclaration(angularCoreEnv, `ng:///${decl.type.name}/ɵprov.js`, decl);
}

function getModuleFactory(id) {
  const type = getRegisteredNgModuleType(id);
  if (!type) throw noModuleError(id);
  return new NgModuleFactory(type);
}
function getNgModuleById(id) {
  const type = getRegisteredNgModuleType(id);
  if (!type) throw noModuleError(id);
  return type;
}
function noModuleError(id) {
  return new RuntimeError(920, ngDevMode && `No module with ID ${id} loaded`);
}

class ViewRef extends ChangeDetectorRef {}
class EmbeddedViewRef extends ViewRef {}

const platformCore = createPlatformFactory(null, 'core', []);

function createComponent(component, options) {
  ngDevMode && assertComponentDef(component);
  const componentDef = getComponentDef(component);
  const elementInjector = options.elementInjector || getNullInjector();
  const factory = new ComponentFactory(componentDef);
  return factory.create(elementInjector, options.projectableNodes, options.hostElement, options.environmentInjector, options.directives, options.bindings);
}
function reflectComponentType(component) {
  const componentDef = getComponentDef(component);
  if (!componentDef) return null;
  const factory = new ComponentFactory(componentDef);
  return {
    get selector() {
      return factory.selector;
    },
    get type() {
      return factory.componentType;
    },
    get inputs() {
      return factory.inputs;
    },
    get outputs() {
      return factory.outputs;
    },
    get ngContentSelectors() {
      return factory.ngContentSelectors;
    },
    get isStandalone() {
      return componentDef.standalone;
    },
    get isSignal() {
      return componentDef.signals;
    }
  };
}

function resourceFromSnapshots(source) {
  return new SnapshotResource(isSignal(source) ? source : computed(source));
}
class SnapshotResource {
  snapshot;
  constructor(snapshot) {
    this.snapshot = snapshot;
  }
  get state() {
    return this.snapshot();
  }
  value = computed(() => {
    if (this.state.status === 'error') {
      throw new ResourceValueError(this.state.error);
    }
    return this.state.value;
  });
  status = computed(() => this.state.status);
  error = computed(() => this.state.status === 'error' ? this.state.error : undefined);
  isLoading = computed(() => this.state.status === 'loading' || this.state.status === 'reloading');
  isValueDefined = computed(() => this.state.status !== 'error' && this.state.value !== undefined);
  hasValue() {
    return this.isValueDefined();
  }
}

function debounced(source, wait, options) {
  if (isInParamsFunction()) {
    throw invalidResourceCreationInParams();
  }
  if (ngDevMode && !options?.injector) {
    assertInInjectionContext(debounced);
  }
  const injector = options?.injector ?? inject(Injector);
  let active;
  let pendingValue;
  injector.get(DestroyRef).onDestroy(() => {
    active = undefined;
  });
  const state = linkedSignal({
    source: () => {
      try {
        setInParamsFunction(true);
        return {
          value: source(),
          thrown: false
        };
      } catch (err) {
        rethrowFatalErrors(err);
        return {
          error: err,
          thrown: true
        };
      } finally {
        setInParamsFunction(false);
      }
    },
    computation: (res, previous) => {
      if (previous !== undefined) {
        return previous.value;
      }
      if (res.thrown) {
        return {
          status: 'error',
          error: res.error
        };
      }
      return {
        status: 'resolved',
        value: res.value
      };
    }
  });
  effect(() => {
    let value;
    try {
      setInParamsFunction(true);
      value = source();
    } catch (err) {
      rethrowFatalErrors(err);
      state.set({
        status: 'error',
        error: err
      });
      active = pendingValue = undefined;
      return;
    } finally {
      setInParamsFunction(false);
    }
    const currentState = untracked(state);
    const equal = options?.equal ?? Object.is;
    if (currentState.status === 'reloading' || currentState.status === 'loading') {
      if (equal(value, pendingValue)) return;
    } else if (currentState.status === 'resolved') {
      if (equal(value, currentState.value)) return;
    }
    const waitFn = typeof wait === 'number' ? () => new Promise(resolve => setTimeout(resolve, wait)) : wait;
    const result = waitFn(value, currentState);
    if (result === undefined) {
      state.set({
        status: 'resolved',
        value
      });
      active = pendingValue = undefined;
    } else {
      if (currentState.status !== 'loading' && currentState.status !== 'error') {
        state.set({
          status: 'loading',
          value: currentState.value
        });
      }
      active = result;
      pendingValue = value;
      result.then(() => {
        if (active === result) {
          state.set({
            status: 'resolved',
            value
          });
          active = pendingValue = undefined;
        }
      });
    }
  }, {
    injector
  });
  return resourceFromSnapshots(state);
}

const RESOLVED_SIGNAL = /* @__PURE__ */Symbol('RESOLVED_SIGNAL');
function resolved(resource) {
  const getter = () => {
    const consumer = getActiveConsumer();
    if (consumer !== null && consumer.kind === 'computed') {
      consumer.kind = 'asyncComputed';
    }
    ngDevMode && assertAsyncReadAllowed(resolved);
    switch (resource.status()) {
      case 'resolved':
      case 'local':
      case 'reloading':
        return resource.value();
      case 'error':
        if (consumer?.kind === 'effect') {
          throw NotReady;
        }
        throw resource.error() ?? new Error('Resource error');
      case 'idle':
        throw isInParamsFunction() ? ResourceParamsStatus.IDLE : NotReady;
      default:
        throw isInParamsFunction() ? ResourceParamsStatus.LOADING : NotReady;
    }
  };
  getter[SIGNAL] = true;
  getter[RESOLVED_SIGNAL] = true;
  if (typeof ngDevMode !== 'undefined' && ngDevMode) {
    getter.toString = () => `[Resolved: ${String(resource.status())}]`;
  }
  return getter;
}
function isResolvedSignal(value) {
  return typeof value === 'function' && value[RESOLVED_SIGNAL] === true;
}

function isDevMode() {
  return typeof ngDevMode === 'undefined' || !!ngDevMode;
}
function enableProdMode() {
  if (typeof ngDevMode === 'undefined' || ngDevMode) {
    _global['ngDevMode'] = false;
  }
}

async function declareExperimentalWebMcpTool(tool, injector) {
  if (typeof ngServerMode !== 'undefined' && ngServerMode) return;
  const modelContext = globalThis.document.modelContext ?? globalThis.navigator.modelContext;
  if (!modelContext || typeof modelContext.registerTool !== 'function') return;
  if (typeof ngDevMode !== 'undefined' && ngDevMode) {
    if (!injector) assertInInjectionContext(declareExperimentalWebMcpTool);
  }
  const currentInjector = injector ?? inject(Injector);
  const destroyRef = currentInjector.get(DestroyRef);
  const abortCtrl = new AbortController();
  const wrappedTool = {
    ...tool,
    execute: (args, client) => runInInjectionContext(currentInjector, () => tool.execute(args, {
      ...client,
      signal: abortCtrl.signal
    }))
  };
  destroyRef.onDestroy(() => void abortCtrl.abort());
  await modelContext.registerTool(wrappedTool, {
    signal: abortCtrl.signal
  });
}

function provideExperimentalWebMcpTools(tools) {
  return makeEnvironmentProviders([provideEnvironmentInitializer(() => {
    for (const tool of tools) declareExperimentalWebMcpTool(tool);
  })]);
}

export { APP_BOOTSTRAP_LISTENER, APP_ID, ApplicationInitStatus, ApplicationModule, ApplicationRef, COMPILER_OPTIONS, ChangeDetectorRef, ContentChild, ContentChildren, DOCUMENT, DefaultIterableDiffer, DestroyRef, ENVIRONMENT_INITIALIZER, EmbeddedViewRef, ErrorHandler, HOST_TAG_NAME, HostAttributeToken, Injectable, InjectionToken, Injector, IterableDiffers, KeyValueDiffers, LOCALE_ID, NgModule, NgZone, NotReady, OutputEmitterRef, PLATFORM_INITIALIZER, PlatformRef, Query, REQUEST, REQUEST_CONTEXT, RESOLVED_SIGNAL, RESPONSE_INIT, ResourceParamsStatus, Service, TransferState, ViewChild, ViewChildren, ViewEncapsulation$1 as ViewEncapsulation, ViewRef, afterRenderEffect, assertInInjectionContext, assertNotInReactiveContext, assertPlatform, booleanAttribute, computed, contentChild, contentChildren, createComponent, createPlatform, createPlatformFactory, debounced, declareExperimentalWebMcpTool, destroyPlatform, effect, enableProdMode, getModuleFactory, getNgModuleById, getPlatform, inject, injectAsync, input, isDevMode, isResolvedSignal, isSignal, linkedSignal, makeEnvironmentProviders, mergeApplicationConfig, model, numberAttribute, onIdle, output, platformCore, provideAppInitializer, provideCheckNoChangesConfig, provideEnvironmentInitializer, provideExperimentalWebMcpTools, providePlatformInitializer, provideStabilityDebugging, provideZoneChangeDetection, reflectComponentType, resolved, resourceFromSnapshots, runInInjectionContext, untracked, viewChild, viewChildren, AfterRenderManager as ɵAfterRenderManager, CLIENT_RENDER_MODE_FLAG as ɵCLIENT_RENDER_MODE_FLAG, CONTAINER_HEADER_OFFSET as ɵCONTAINER_HEADER_OFFSET, ChangeDetectionScheduler as ɵChangeDetectionScheduler, Console as ɵConsole, DEFAULT_LOCALE_ID as ɵDEFAULT_LOCALE_ID, DEHYDRATED_BLOCK_REGISTRY as ɵDEHYDRATED_BLOCK_REGISTRY, ENABLE_ROOT_COMPONENT_BOOTSTRAP as ɵENABLE_ROOT_COMPONENT_BOOTSTRAP, EVENT_REPLAY_QUEUE as ɵEVENT_REPLAY_QUEUE, Framework as ɵFramework, IMAGE_CONFIG as ɵIMAGE_CONFIG, INJECTOR_SCOPE as ɵINJECTOR_SCOPE, ɵINPUT_SIGNAL_BRAND_WRITE_TYPE, INTERNAL_APPLICATION_ERROR_HANDLER as ɵINTERNAL_APPLICATION_ERROR_HANDLER, IS_HYDRATION_DOM_REUSE_ENABLED as ɵIS_HYDRATION_DOM_REUSE_ENABLED, IS_INCREMENTAL_HYDRATION_ENABLED as ɵIS_INCREMENTAL_HYDRATION_ENABLED, JSACTION_BLOCK_ELEMENT_MAP as ɵJSACTION_BLOCK_ELEMENT_MAP, JSACTION_EVENT_CONTRACT as ɵJSACTION_EVENT_CONTRACT, NgModuleFactory as ɵNgModuleFactory, PERFORMANCE_MARK_PREFIX as ɵPERFORMANCE_MARK_PREFIX, PROVIDED_NG_ZONE as ɵPROVIDED_NG_ZONE, PROVIDED_ZONELESS as ɵPROVIDED_ZONELESS, PendingTasksInternal as ɵPendingTasksInternal, ProfilerEvent as ɵProfilerEvent, R3Injector as ɵR3Injector, ComponentFactory as ɵRender3ComponentFactory, RuntimeError as ɵRuntimeError, SIGNAL as ɵSIGNAL, TracingService as ɵTracingService, ViewRef$1 as ɵViewRef, ZONELESS_ENABLED as ɵZONELESS_ENABLED, annotateForHydration as ɵannotateForHydration, ɵassertType, compileNgModuleFactory as ɵcompileNgModuleFactory, createOrReusePlatformInjector as ɵcreateOrReusePlatformInjector, defaultIterableDiffers as ɵdefaultIterableDiffers, defaultKeyValueDiffers as ɵdefaultKeyValueDiffers, disableProfiling as ɵdisableProfiling, enableProfiling as ɵenableProfiling, formatRuntimeError as ɵformatRuntimeError, getComponentDef as ɵgetComponentDef, getCurrentClosestComponentInstance as ɵgetCurrentClosestComponentInstance, getDocument as ɵgetDocument, getLContext as ɵgetLContext, _global as ɵglobal, injectChangeDetectorRef as ɵinjectChangeDetectorRef, internalCreateApplication as ɵinternalCreateApplication, internalProvideZoneChangeDetection as ɵinternalProvideZoneChangeDetection, isInParamsFunction as ɵisInParamsFunction, isPromise as ɵisPromise, maybeUnwrapDefaultExport as ɵmaybeUnwrapDefaultExport, performanceMarkFeature as ɵperformanceMarkFeature, promiseWithResolvers as ɵpromiseWithResolvers, provideZonelessChangeDetectionInternal as ɵprovideZonelessChangeDetectionInternal, resolveComponentResources as ɵresolveComponentResources, setClassMetadata as ɵsetClassMetadata, setClassMetadataAsync as ɵsetClassMetadataAsync, setInParamsFunction as ɵsetInParamsFunction, setInjectorProfilerContext as ɵsetInjectorProfilerContext, setLocaleId as ɵsetLocaleId, startMeasuring as ɵstartMeasuring, stopMeasuring as ɵstopMeasuring, stringify as ɵstringify, withDomHydration as ɵwithDomHydration, withEventReplay as ɵwithEventReplay, withI18nSupport as ɵwithI18nSupport, withIncrementalHydration as ɵwithIncrementalHydration, FactoryTarget as ɵɵFactoryTarget, __defineInjectable as ɵɵdefineInjectable, __defineInjector as ɵɵdefineInjector, __defineNgModule as ɵɵdefineNgModule, __defineService as ɵɵdefineService, __inject as ɵɵinject, __injectAttribute as ɵɵinjectAttribute, ɵɵngDeclareClassMetadata, ɵɵngDeclareClassMetadataAsync, ɵɵngDeclareComponent, ɵɵngDeclareDirective, ɵɵngDeclareFactory, ɵɵngDeclareInjectable, ɵɵngDeclareInjector, ɵɵngDeclareNgModule, ɵɵngDeclarePipe, ɵɵngDeclareService };
//# sourceMappingURL=core.mjs.map
