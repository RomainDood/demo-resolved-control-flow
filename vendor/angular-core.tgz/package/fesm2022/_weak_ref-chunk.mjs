/**
 * @license Angular v22.2.0-next.1+sha-87e0a24-with-local-changes
 * (c) 2010-2026 Google LLC. https://angular.dev/
 * License: MIT
 */

function setAlternateWeakRefImpl(impl) {}

export { setAlternateWeakRefImpl };
//# sourceMappingURL=_weak_ref-chunk.mjs.map
