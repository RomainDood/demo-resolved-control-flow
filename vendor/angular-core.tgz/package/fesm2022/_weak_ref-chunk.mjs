/**
 * @license Angular v0.0.0
 * (c) 2010-2026 Google LLC. https://angular.dev/
 * License: MIT
 */

function setAlternateWeakRefImpl(impl) {}

export { setAlternateWeakRefImpl };
//# sourceMappingURL=_weak_ref-chunk.mjs.map
