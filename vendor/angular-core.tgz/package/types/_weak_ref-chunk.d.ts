/**
 * @license Angular v0.0.0
 * (c) 2010-2026 Google LLC. https://angular.dev/
 * License: MIT
 */

/**
 * Sentinel thrown when an async reactive value is not yet settled.
 *
 * Identity-comparable: always throw/catch `NotReady` itself, not a new instance.
 */
declare const NotReady: unique symbol;
declare function isNotReady(error: unknown): error is typeof NotReady;
/**
 * Sentinel thrown when a resource has not started loading yet (`idle`).
 *
 * Distinct from `NotReady` so `@idle` can be shown instead of `@loading`.
 */
declare const Idle: unique symbol;
declare function isIdle(error: unknown): error is typeof Idle;
/** True when an async read is paused on either idle or loading. */
declare function isAsyncPause(error: unknown): error is typeof NotReady | typeof Idle;

declare function setAlternateWeakRefImpl(impl: unknown): void;

export { Idle, NotReady, isAsyncPause, isIdle, isNotReady, setAlternateWeakRefImpl };
