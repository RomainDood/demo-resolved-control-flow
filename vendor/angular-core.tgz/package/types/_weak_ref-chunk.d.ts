/**
 * @license Angular v0.0.0
 * (c) 2010-2026 Google LLC. https://angular.dev/
 * License: MIT
 */

/**
 * Sentinel thrown when an async reactive value is not yet settled.
 *
 * Identity-comparable: always throw/catch `NotReady` itself, not a new instance.
 */
declare const NotReady: unique symbol;
declare function isNotReady(error: unknown): error is typeof NotReady;

declare function setAlternateWeakRefImpl(impl: unknown): void;

export { NotReady, isNotReady, setAlternateWeakRefImpl };
