/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */
// THIS CODE IS GENERATED - DO NOT MODIFY.
const u = undefined;
export default [[["canol nos", "canol dydd", "yn y bore", "yn y prynhawn", "min nos"], ["canol nos", "canol dydd", "y bore", "y prynhawn", "yr hwyr"], u], [["canol nos", "canol dydd", "bore", "prynhawn", "min nos"], ["canol nos", "canol dydd", "bore", "prynhawn", "yr hwyr"], ["canol nos", "canol dydd", "y bore", "y prynhawn", "yr hwyr"]], ["00:00", "12:00", ["00:00", "12:00"], ["12:00", "18:00"], ["18:00", "24:00"]]];
//# sourceMappingURL=cy.js.map